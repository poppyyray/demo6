db_hostname=9.110.246.42
db_instancename=SQLEXPRESS
db_dbname=KAO_CH_201607
db_user=kao
db_password=passw0rd
db_driverClass=com.microsoft.sqlserver.jdbc.SQLServerDriver
db_type=jdbc:sqlserver://