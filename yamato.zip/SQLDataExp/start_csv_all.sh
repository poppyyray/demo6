#db env
source ./setenv.sh

sql_filepath=/sql
sql_encode=UTF-8
output_encode=UTF-8
threadnum=3

#file bom(1:has bom,0:no bom)
isUTF8BOM=1

#output folder
output_path=output/201701

csvGetterEnv="-Ddb_hostname=${db_hostname} -Ddb_instancename=${db_instancename} -Ddb_dbname=${db_dbname} -Ddb_user=${db_user} -Ddb_password=${db_password} -Ddb_driverClass=${db_driverClass} -Ddb_type=${db_type} -Dsql_filepath=${sql_filepath} -Dsql_lineseparator=${sql_lineseparator} -Dsql_encode=${sql_encode} -Doutput_path=${output_path} -Doutput_encode=${output_encode} -Dthreadnum=${threadnum} -DisUTF8BOM=${isUTF8BOM}"

java ${csvGetterEnv} -jar SQLDataExp.jar /sql/csv_R01.properties d
java ${csvGetterEnv} -jar SQLDataExp.jar /sql/csv_R02.properties
java ${csvGetterEnv} -jar SQLDataExp.jar /sql/csv_R03.properties
java ${csvGetterEnv} -jar SQLDataExp.jar /sql/csv_R04.properties
java ${csvGetterEnv} -jar SQLDataExp.jar /sql/csv_R05.properties