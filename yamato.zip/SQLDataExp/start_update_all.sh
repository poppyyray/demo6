#db env
source ./setenv.sh
sql_filepath=/sql
sql_encode=UTF-8
output_encode=UTF-8
threadnum=3

#file bom(1:has bom,0:no bom)
isUTF8BOM=1

#query date
query_startdate=20160101
query_enddate=20161231

csvGetterEnv="-Ddb_hostname=${db_hostname} -Ddb_instancename=${db_instancename} -Ddb_dbname=${db_dbname} -Ddb_user=${db_user} -Ddb_password=${db_password} -Ddb_driverClass=${db_driverClass} -Ddb_type=${db_type} -Dsql_filepath=${sql_filepath} -Dsql_lineseparator=${sql_lineseparator} -Dsql_encode=${sql_encode} -Doutput_encode=${output_encode} -Dthreadnum=${threadnum} -Dquery_startdate=${query_startdate} -Dquery_enddate=${query_enddate} -DisUTF8BOM=${isUTF8BOM}"

echo ${csvGetterEnv}
java ${csvGetterEnv} -jar SQLDataExp.jar /sql/upd_R00.properties
java ${csvGetterEnv}  -Dquery_startdate=20160201 -Dquery_enddate=20160401 -jar SQLDataExp.jar /sql/upd_R01.properties
java ${csvGetterEnv} -jar SQLDataExp.jar /sql/upd_R02.properties
java ${csvGetterEnv} -jar SQLDataExp.jar /sql/upd_R03.properties
java ${csvGetterEnv} -jar SQLDataExp.jar /sql/upd_R04.properties
java ${csvGetterEnv} -jar SQLDataExp.jar /sql/upd_R05.properties
