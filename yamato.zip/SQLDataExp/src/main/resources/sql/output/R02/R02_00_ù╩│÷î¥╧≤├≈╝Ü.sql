SELECT * FROM CFAV_R02_00_検出対象明細   order by Applicant_ID,Monitoring_No;
