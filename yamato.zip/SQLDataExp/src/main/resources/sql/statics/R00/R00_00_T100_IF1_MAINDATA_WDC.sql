DROP TABLE TDGTMP001_R00_00_T100_IF1_MAINDATA_WDC
GO
SELECT   
	A1.*,
	(CASE SUBSTRING(A1.MONITORING_NO,1,2) 
		when '30' then '8D'
		when '31' then '8E'
		when '32' then '8F'
		when '33' then '8A'
		when '34' then '8H'
		when '35' then '8J'
		when '36' then '8B'
		when '37' then '8I'
		when '38' then '8C'
		when '39' then '8G'
		when '42' then '8K'
		when '43' then '8L'
		when '44' then '8L'
		when '45' then '8M'
		when '46' then '8M'
		when '47' then '8N'
		when '48' then '83'
		when '50' then '8P'
		when '51' then '8Q'
		when '52' then '83'
		when '53' then '8R'
		when '54' then '8S'
		when '55' then '8T'
		when '56' then '8K'
		when '57' then '8M'
		when '58' then '83'
		when '60' then '8U'
		when '61' then '8U'
		when '62' then '8U'
		when '63' then '8V'
		when '64' then '8V'
		when '65' then '83'
		ELSE NULL END) AS DATA_CLASS
INTO
		TDGTMP001_R00_00_T100_IF1_MAINDATA_WDC
FROM    DBO.T100_IF1_MAINDATA A1,
		DBO.T110_IF1_MAINSTATUS A2
WHERE   
         A2.MONITORING_STATUS=1
         AND A1.MONITORING_NO=A2.MONITORING_NO
         