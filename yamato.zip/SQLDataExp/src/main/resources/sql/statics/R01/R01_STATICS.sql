SELECT COUNT( DISTINCT A1.Applicant_ID ) as 検出人数, COUNT( DISTINCT A1.Monitoring_No ) as 検出件数, SUM(A1.Total_CNY) AS 検出金額
FROM DBO.CFAV_R01_00_検出対象明細 A1 