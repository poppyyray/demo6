DROP VIEW CFAV_R05_02_検出対象明細_3件以上;
GO
CREATE VIEW CFAV_R05_02_検出対象明細_3件以上
AS
-- 明細抽出
--------------------------------------------------------
SELECT 
    A1.*
FROM 
    DBO.CFAV_R05_00_検出対象明細  A1,
    DBO.CFAV_R05_01_取引先別の集計 A2
WHERE 
    A1.APPLICANT_ID = A2.APPLICANT_ID
    AND A2.MON_CNT >3                                 --3件以上NG
;
