/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/auth/OppStatusGateway.java,v 1.5 2003/12/17 10:16:29 k_ushio Exp $
 * VERSION   : $Revision: 1.5 $
 * DATE      : $Date: 2003/12/17 10:16:29 $
 * HISTORY   : 
 * COPYRIGHT : (c)Copyright Fuji Xerox Co., Ltd. 2003 All rights reserved.
 *             Copyright(c)Oracle Corporation Japan, 2003. All rights reserved.
 */

package oracle.apps.xxsc.auth;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.DynaBean;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.config.ModuleConfig;

import oracle.fwk.ext.struts.config.Gateway;

import oracle.apps.xxsc.BusinessConstants;


/**
 * ���k�󋵃`�F�b�N���s���܂��B
 *
 * @author  
 * @version  $Revision: 1.5 $ $Date: 2003/12/17 10:16:29 $
 */
public final class SessionInfoChkGateway 
	extends XxscGatewayBase implements Gateway, BusinessConstants {

// ---------------------------------------------- Protected Methods.
// ------------------------------------------------------------------

	/**
	 * ���O�C���A�N�V�����ȊO�̏ꍇ�� <br />
	 * �Z�b�V���������݂��邩�`�F�b�N���s���܂��B<br /><br />
	 *
	 * @param request  {@link javax.servlet.http.HttpServletRequest} �I�u�W�F�N�g
	 * @param response  {@link javax.servlet.http.HttpServletResponse} �I�u�W�F�N�g
	 * @param servlet  {@link org.apache.struts.action.ActionServlet} �I�u�W�F�N�g
	 * @param moduleConfig  {@link org.apache.struts.config.ModuleConfig} �I�u�W�F�N�g
	 * @return boolean  
	 *     �F�،���OK�ł���� <code>false</code>�ANG�ł���� <code>true</code> ��Ԃ��܂��B
	 * @exception java.lang.Exception
	 */
	protected final boolean validateProcess(HttpServletRequest request, 
	                                        HttpServletResponse response, 
	                                        ActionServlet servlet, 
	                                        ModuleConfig moduleConfig) 
	throws Exception {

		String servletPath = request.getServletPath();
		log.debug("servletPath : " + servletPath);

		List loginUrlList = getLoginUrlList(servlet);
		log.debug("loginUrlList : " + loginUrlList);

		if (loginUrlList.indexOf(servletPath) != -1) {
			// OK ...
			return false;
		}

		DynaBean loginInfo = 
			(DynaBean)request.getSession(true).getAttribute(LOGIN_INFO);
		if (loginInfo == null) {
			return true;
		}

		// OK ...
		return false;
	}

	/**
	 * init.xml���烍�O�C���A�N�V������url���擾���܂��B
	 * 
	 * @param servlet  {@link org.apache.struts.action.ActionServlet} �I�u�W�F�N�g
	 * @exception java.lang.Exception
	 */
	protected List getLoginUrlList(ActionServlet servlet) throws Exception {

		List loginUrlList = new ArrayList();
		String loginUrl = null;
		int i =0;

		while (true) {
			loginUrl = findInitParameter(servlet, "loginUrl" + i);
			log.debug("loginUrl" + i + " : " + loginUrl);

			if (loginUrl == null || "".equals(loginUrl)) {
				break;
			}
			loginUrlList.add(loginUrl);
			i++;
		}
		return loginUrlList;
	}

// ---------------------------------------------- Logging Fields.
// ------------------------------------------------------------------

	private static final Logger log = Logger.getLogger(SessionInfoChkGateway.class);
}

