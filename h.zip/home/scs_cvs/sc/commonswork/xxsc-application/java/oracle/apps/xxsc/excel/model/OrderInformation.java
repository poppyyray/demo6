/* the Apache Software Foundation license */
/*
 * FILE      : $Header : $
 * VERSION   : $Revision : $
 * DATE      : $Date : $
 * HISTORY   : 
 * COPYRIGHT : Copyright (c) 2003, Fuji Xerox. All rights reserved.
 */
package oracle.apps.xxsc.excel.model;

/**
 * �󒍏��N���X
 * @author NCD sugimura
 * @version $Revision :
 */
public class OrderInformation {

	// �Z�b�gID
	private String contractUnitId;
	// �_��A��
	private String contractNumber;
	// �󒍃^�C�v
	private String orderType;
	// �g�DID
	private String orgId;
	// �󒍔ԍ�
	private String orderNumber;
	// �󒍃^�C�v��
	private String orderTypeName;
	// ����R�[�h
	private String depCode;
	// �󒍉�Ж�
	private String companyName;
	// ����X���Ə��敪
	private String dealershipType;
	
	//------------------ ��������A�N�Z�b�T�E���\�b�h

	/**
	 * @return
	 */
	public String getContractNumber() {
		return contractNumber;
	}

	/**
	 * @return
	 */
	public String getContractUnitId() {
		return contractUnitId;
	}

	/**
	 * @return
	 */
	public String getOrderNumber() {
		return orderNumber;
	}

	/**
	 * @return
	 */
	public String getOrderType() {
		return orderType;
	}

	/**
	 * @return
	 */
	public String getOrgId() {
		return orgId;
	}

	/**
	 * @param string
	 */
	public void setContractNumber(String string) {
		contractNumber = string;
	}

	/**
	 * @param string
	 */
	public void setContractUnitId(String string) {
		contractUnitId = string;
	}

	/**
	 * @param string
	 */
	public void setOrderNumber(String string) {
		orderNumber = string;
	}

	/**
	 * @param string
	 */
	public void setOrderType(String string) {
		orderType = string;
	}

	/**
	 * @param string
	 */
	public void setOrgId(String string) {
		orgId = string;
	}

	/**
	 * @return
	 */
	public String getOrderTypeName() {
		return orderTypeName;
	}

	/**
	 * @param string
	 */
	public void setOrderTypeName(String string) {
		orderTypeName = string;
	}
	
	/**
	 * @return
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * @return
	 */
	public String getDepCode() {
		return depCode;
	}

	/**
	 * @param string
	 */
	public void setCompanyName(String string) {
		companyName = string;
	}

	/**
	 * @param string
	 */
	public void setDepCode(String string) {
		depCode = string;
	}

	/**
	 * @return
	 */
	public String getDealershipType() {
		return dealershipType;
	}

	/**
	 * @param string
	 */
	public void setDealershipType(String string) {
		dealershipType = string;
	}

	//------------------ �����܂ŃA�N�Z�b�T�E���\�b�h
	
	/**
	 * �{�I�u�W�F�N�g������������<BR>
	 *
	 * @return		OrderInformation	�������g
	 * @exception	Exception	   �������ɃG���[�����������ꍇ
	 */	
	public OrderInformation createModel() throws Exception {
		
		return this;
	}
}
