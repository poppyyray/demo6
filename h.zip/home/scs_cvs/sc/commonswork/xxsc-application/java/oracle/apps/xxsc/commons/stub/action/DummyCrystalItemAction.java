/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/commons/stub/action/DummyCrystalItemAction.java,v 1.2 2003/09/24 10:15:42 h_okita Exp $
 * VERSION   : $Revision: 1.2 $
 * DATE      : $Date: 2003/09/24 10:15:42 $
 * HISTORY   : 
 * COPYRIGHT : (c)Copyright Fuji Xerox Co., Ltd. 2003 All rights reserved.
 *             Copyright(c)Oracle Corporation Japan, 2003. All rights reserved.
 */

package oracle.apps.xxsc.commons.stub.action;

import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.commons.beanutils.DynaBean;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.DynaActionForm;
import org.apache.struts.action.ActionMapping;

import oracle.apps.xxsc.ActionTemplate;

/**
 * <p><h3>�^��Crystal���i�ǉ�</h3></p>
 *
 * <p>
 * �������i�ݒ�iCrystal�j����Ăяo�����CrystalSystem��Stub�B
 * �_�~�[��ʂ֏��̏o�́B
 * </p>
 *
 * @author Tatsuya Seki
 * @version $Revision: 1.2 $
 */

public class DummyCrystalItemAction extends ActionTemplate {

    // From CRY001 submit datas Mapping Object.
    private Map cry001dataMap = new HashMap();

	public ActionForward process(ActionMapping mapping, DynaActionForm form) 
		throws Exception {

		getLog().debug(" �� class : CrystalNewItemAction ");

        // --------------------- get POST data ---------------------------------
        getLog().debug(" �� POST data : Item data list ");
        // get POST Crystal Price datas loop processing....
        Enumeration paramNames = request.getParameterNames();
        while ( paramNames.hasMoreElements() ) {
            String parameterKey = (String) paramNames.nextElement();
            String parameterValue
                = (String) request.getParameter(parameterKey);

            getLog().debug(" �� " + parameterKey + " = " + parameterValue); 
            // Mapping get submit data
            cry001dataMap.put(parameterKey, parameterValue);              
        }
        getLog().debug(" �� POST data : Item data list ");

        // set new submit data from Mapping Object 
        getLog().debug(" �� POST data : new Price data list ");

        // get Map Object size.
        int idx = 1;

        // set XtalAddItems header infomations.
        request.setAttribute("opportunities_number", 
                             cry001dataMap.get("opportunities_number"));
        request.setAttribute("contract_unit_number",
                              cry001dataMap.get("contract_unit_number"));
        request.setAttribute("number_of_sets",
                              cry001dataMap.get("number_of_sets"));

        // set data list
        ArrayList submitList = new ArrayList();
        // records
        HashMap map = new HashMap();
        boolean loopFlag = true;

        while ( loopFlag ) {

            // make data Key
            String keyOpportunitiesLineNumber
                 = new String("opportunities_line_number_");
            String keyItemDescription
                 = new String("item_description_");
            String keyMakerModelNumber
                 = new String("maker_model_number_");
            String keyMakerName
                 = new String("maker_name_");
            String keyVenderName
                 = new String("vender_name_");
            String keyNumberOfItems
                 = new String("number_of_items_");
            String keySalesListPrice
                 = new String("sales_list_price_");
            String keyInvoicePrice
                 = new String("invoice_price_");
            String keyVenderDapertmentName
                 = new String("vender_dapertment_name_");
            String keyVenderContactName
                 = new String("vender_contact_name_");
            String keyVenderTel
                 = new String("vender_tel_");
            String keyVenderEstimateNumber
                 = new String("vender_estimate_number_");
            String keyVenderCode
                 = new String("vender_code_");
            String keyMakerCode
                 = new String("maker_code_");
            String keyVenderItemCode
                 = new String("vender_item_code_");
            String keyDataSelectType
                 = new String("data_select_type_");
            String keyOpenPriceType
                 = new String("open_price_type_");
            String keyLineStatus
                 = new String("line_status_");

            // set index in Key
            keyOpportunitiesLineNumber
                = keyOpportunitiesLineNumber + String.valueOf(idx);
            keyItemDescription
                = keyItemDescription + String.valueOf(idx);
            keyMakerModelNumber
                = keyMakerModelNumber + String.valueOf(idx);
            keyMakerName
                = keyMakerName + String.valueOf(idx);
            keyVenderName
                = keyVenderName + String.valueOf(idx);
            keyNumberOfItems
                = keyNumberOfItems + String.valueOf(idx);
            keySalesListPrice
                = keySalesListPrice + String.valueOf(idx);
            keyInvoicePrice
                = keyInvoicePrice + String.valueOf(idx);
            keyVenderDapertmentName
                = keyVenderDapertmentName + String.valueOf(idx);
            keyVenderContactName
                = keyVenderContactName + String.valueOf(idx);
            keyVenderTel
                = keyVenderTel + String.valueOf(idx);
            keyVenderEstimateNumber
                = keyVenderEstimateNumber + String.valueOf(idx);
            keyVenderCode
                = keyVenderCode + String.valueOf(idx);
            keyMakerCode
                = keyMakerCode + String.valueOf(idx);
            keyVenderItemCode
                = keyVenderItemCode + String.valueOf(idx);
            keyDataSelectType
                = keyDataSelectType + String.valueOf(idx);
            keyOpenPriceType
                = keyOpenPriceType + String.valueOf(idx);
            keyLineStatus
                = keyLineStatus + String.valueOf(idx);

            // loop continue judgement.
            if ( !cry001dataMap.containsKey(keyOpportunitiesLineNumber) ) {
                getLog().debug(" �� POST data : new Price data list ");
                break;
            }

            // return constant values.
            map.put(keyOpportunitiesLineNumber, cry001dataMap.get(keyOpportunitiesLineNumber));
            map.put(keyItemDescription, cry001dataMap.get(keyItemDescription));
            map.put(keyMakerModelNumber, cry001dataMap.get(keyMakerModelNumber));
            map.put(keyMakerName, cry001dataMap.get(keyMakerName));
            map.put(keyVenderName, cry001dataMap.get(keyVenderName));
            map.put(keyNumberOfItems, cry001dataMap.get(keyNumberOfItems));
            map.put(keySalesListPrice, cry001dataMap.get(keySalesListPrice));
            map.put(keyInvoicePrice, cry001dataMap.get(keyInvoicePrice));
            map.put(keyVenderDapertmentName, cry001dataMap.get(keyVenderDapertmentName));
            map.put(keyVenderContactName, cry001dataMap.get(keyVenderContactName));
            map.put(keyVenderTel, cry001dataMap.get(keyVenderTel));
            map.put(keyVenderEstimateNumber, cry001dataMap.get(keyVenderEstimateNumber));
            map.put(keyVenderCode, cry001dataMap.get(keyVenderCode));
            map.put(keyMakerCode, cry001dataMap.get(keyMakerCode));
            map.put(keyVenderItemCode, cry001dataMap.get(keyVenderItemCode));
            map.put(keyDataSelectType, cry001dataMap.get(keyDataSelectType));
            map.put(keyOpenPriceType, cry001dataMap.get(keyOpenPriceType));
            map.put(keyLineStatus, cry001dataMap.get(keyLineStatus));

            submitList.add(map);
            idx++;
        }

        // set list data.
        request.setAttribute("submitData", submitList);

        getLog().debug(" �� setList = " + submitList);
        getLog().debug(" �� POST data : new Price data list ");
		getLog().debug(" �� class : CrystalNewPriceAction ");

		return mapping.findForward("success");
    }
}