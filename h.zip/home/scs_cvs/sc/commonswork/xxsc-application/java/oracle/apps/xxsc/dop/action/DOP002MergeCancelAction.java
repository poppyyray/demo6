/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/dop/action/DOP002MergeCancelAction.java,v 1.12 2003/10/09 05:56:22 k_ushio Exp $
 * VERSION   : $Revision: 1.12 $
 * DATE      : $Date: 2003/10/09 05:56:22 $
 * HISTORY   : 
 * COPYRIGHT : (c)Copyright Fuji Xerox Co., Ltd. 2003 All rights reserved.
 *             Copyright(c)Oracle Corporation Japan, 2003. All rights reserved.
 */

package oracle.apps.xxsc.dop.action;

import java.util.List;

import oracle.apps.xxsc.ActionTemplate;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;

/**
 * <p><h3>�u����܂Ƃߕ����܂Ƃ߉����N���X�v</h3></p>
 *
 * <p>
 * ����܂Ƃߕ����̂܂Ƃ߉������s���B
 * </p>
 *
 * @author Takashi Hatanaka
 * @version $Revision: 1.12 $ $Date: 2003/10/09 05:56:22 $
 */
public class DOP002MergeCancelAction extends ActionTemplate {

	/**
	 * <p>
	 * �����܂Ƃ߂���������B
	 * </p>
	 *
	 * @param mapping  {@link org.apache.struts.action.ActionMapping} �I�u�W�F�N�g
	 * @param form  {@link org.apache.struts.action.DynaActionForm} �I�u�W�F�N�g
	 * @return org.apache.struts.action.ActionForward
	 * @exception java.lang.Exception
	 */
	public ActionForward process(ActionMapping mapping, DynaActionForm form) 
		throws Exception {

		getLog().debug("*DOP002MergeCancelAction#process was start.*");

		// �����܂Ƃ߉���
		if (!cancelFeeMerge(form)) {
			return mapping.findForward("failure");
		}

		getLog().debug("*DOP002MergeCancelAction#process was end.*");
		return mapping.findForward("success");
	}

	/**
	 * <p>
	 * �܂Ƃ߉������s���B
	 * </p>
	 *
	 * @param form  {@link org.apache.struts.action.DynaActionForm} �I�u�W�F�N�g
	 * @return boolean true �܂Ƃ߉�������/false �܂Ƃ߉������s
	 * @exception java.lang.Exception
	 */
	private boolean cancelFeeMerge(DynaActionForm form) throws Exception {

		getLog().debug("*DOP002MergeCancelAction#cancelFeeMerge was start.*");

		// PL/SQL �����ݒ�
		setArrayProc("P1006");

		setParam(5, getOppCode());
		setArrayParam("P1006", 6, (List)form.get("selItemRefTbl"));
		setParam(7, (String)form.get("feeMergeIid"));

		String status = executeArrayProc("P1006");

		if ("U".equals(status) || "E".equals(status)) {
			rollback();
			return false;
		}

		getLog().debug("*DOP002MergeCancelAction#cancelFeeMerge was end.*");
		return true;
	}

	/**
	 * <p>
	 * �Z�b�V��������菤�k�R�[�h���擾����B
	 * </p>
	 *
	 * @return {@link java.lang.String} ���k�R�[�h
	 */
	private String getOppCode() {

		getLog().debug("*DOP002MergeCancelAction#getOppCode was start.*");

		DynaActionForm oppInfo = (DynaActionForm)getAttribute(OPP_INFO, SESSION);

		getLog().debug("*DOP002MergeCancelAction#getOppCode was end.*");
		return (String)oppInfo.get("oppCode");
	}
}
