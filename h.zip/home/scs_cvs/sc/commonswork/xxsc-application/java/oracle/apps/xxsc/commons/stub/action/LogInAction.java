/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/commons/stub/action/LogInAction.java,v 1.2 2003/09/06 09:56:46 d_kakuta Exp $
 * VERSION   : $Revision: 1.2 $
 * DATE      : $Date: 2003/09/06 09:56:46 $
 * HISTORY   : 
 * COPYRIGHT : Copyright (c) 2002-2003, Oracle Corporation Japan. All rights reserved.
 */
package oracle.apps.xxsc.commons.stub.action;

import java.util.ArrayList;
import java.util.List;

import oracle.apps.xxsc.ActionTemplate;
import oracle.fwk.ext.Globals;
import oracle.fwk.ext.struts.ExtStrutsUtils;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;
import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.lang.ObjectUtils;

/**
 * <p>
 * <h3>
 * �_�~�[���O�C���A�N�V�����N���X
 * </h3>
 * </p>
 *
 * <p>
 * <!-- ���� -->
 * </p>
 * 
 * @author Masashi Suda
 * @version $Revision: 1.2 $
 */
public class LogInAction extends ActionTemplate {

	/**
	 * <p>
	 * </p>
	 * 
	 * @param mapping  {@link org.apache.struts.action.ActionMapping} �I�u�W�F�N�g
	 * @param form  {@link org.apache.struts.action.DynaActionForm} �I�u�W�F�N�g
	 * @return org.apache.struts.action.ActionForward
	 * @exception java.lang.Exception
	 */
	public ActionForward process( ActionMapping mapping, DynaActionForm form )
		throws Exception {

		DynaBean loginInfo = lookupDynaForm( "LoginInfo" );
		DynaBean userInfo = lookupDynaForm( USER_INFO );
		DynaBean oppInfo  = lookupDynaForm( OPP_INFO  );
		DynaBean acctInfo = lookupDynaForm( ACCT_INFO );

		loginInfo.set("corpCode",                         getInitParameter("LoginInfo/corpCode"));
		loginInfo.set("userId",                             getInitParameter("LoginInfo/userId"));
		loginInfo.set("respCode",                         getInitParameter("LoginInfo/respCode"));
		loginInfo.set("editType",                         getInitParameter("LoginInfo/editType"));
		userInfo.set("corpCode",                           getInitParameter("UserInfo/corpCode"));
		userInfo.set("corpName",                           getInitParameter("UserInfo/corpName"));
		userInfo.set("dept",                                   getInitParameter("UserInfo/dept"));
		userInfo.set("deptCode",                           getInitParameter("UserInfo/deptCode"));
		userInfo.set("deptName",                           getInitParameter("UserInfo/deptName"));
		userInfo.set("corpId",                               getInitParameter("UserInfo/corpId"));
		userInfo.set("emp",                                     getInitParameter("UserInfo/emp"));
		userInfo.set("empNum",                               getInitParameter("UserInfo/empNum"));
		userInfo.set("empName",                             getInitParameter("UserInfo/empName"));
		userInfo.set("empTel",                               getInitParameter("UserInfo/empTel"));
		userInfo.set("empMail",                             getInitParameter("UserInfo/empMail"));
		userInfo.set("position",                           getInitParameter("UserInfo/position"));

		oppInfo.set("iidOpp",                                 getInitParameter("OppInfo/iidOpp"));
		oppInfo.set("oppCode",                               getInitParameter("OppInfo/oppCode"));
		oppInfo.set("oppName",                               getInitParameter("OppInfo/oppName"));
		oppInfo.set("oppStatusType",                   getInitParameter("OppInfo/oppStatusType"));

		acctInfo.set("oppLoc",                               getInitParameter("AcctInfo/oppLoc"));
		acctInfo.set("oppLocCode",                       getInitParameter("AcctInfo/oppLocCode"));
		acctInfo.set("oppLocName",                       getInitParameter("AcctInfo/oppLocName"));
		acctInfo.set("locContactType",               getInitParameter("AcctInfo/locContactType"));
		acctInfo.set("locContactTypeName",       getInitParameter("AcctInfo/locContactTypeName"));
		acctInfo.set("creditLimitRemainAmnt", getInitParameter("AcctInfo/creditLimitRemainAmnt"));
		acctInfo.set("oppLocOrgId",                     getInitParameter("AcctInfo/oppLocOrgId"));

		List records = (List)ObjectUtils.defaultIfNull(
			ExtStrutsUtils.lookupPageRec(getRequest()), new ArrayList());
		records.add(0, getInitParameter("recordPage"));

		setAttribute("LoginInfo",          loginInfo, SESSION);
		setAttribute(USER_INFO,            userInfo,  SESSION);
		setAttribute(OPP_INFO ,            oppInfo ,  SESSION);
		setAttribute(ACCT_INFO,            acctInfo,  SESSION);
		setAttribute(Globals.PAGE_RECORDS, records,   SESSION);
		
		if (getInitParameter("recordPage").equals("CTS002")) {
			removeAttribute(OPP_INFO, SESSION);
			removeAttribute(ACCT_INFO, SESSION);
		}
		
		DynaActionForm dummyForm = lookupDynaForm("Dummyform");
		dummyForm.set("topPage", mapping.getParameter());
		setAttribute(dummyForm.getDynaClass().getName(), dummyForm, REQUEST);
		
		if (getInitParameter("FormBeanName")==null 
		 || "".equals((String)getInitParameter("FormBeanName"))) {

			return mapping.findForward( "success" );
		}

		DynaBean dummyForm2 = 
		lookupDynaForm((String)getInitParameter("FormBeanName"));

		String propName  = "PropartyName";
		String propValue = "PropartyValue";
		int i = 0;

		while (getInitParameter(propName + Integer.toString(i))!=null 
		    && !"".equals(getInitParameter(propName + Integer.toString(i))) 
		    && getInitParameter(propValue + Integer.toString(i))!=null 
		    && !"".equals(getInitParameter(propValue + Integer.toString(i)))) {

			dummyForm2.set((String)getInitParameter(propName + Integer.toString(i)),
			             (String)getInitParameter(propValue + Integer.toString(i)));
			i++;
		}

		setAttribute((String)getInitParameter("FormBeanName"),
		             dummyForm2, REQUEST);

		return mapping.findForward( "success" );
	}
}
