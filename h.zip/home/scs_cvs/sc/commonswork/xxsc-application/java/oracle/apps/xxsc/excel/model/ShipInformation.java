/* the Apache Software Foundation license */
/*
 * FILE      : $Header : $
 * VERSION   : $Revision : $
 * DATE      : $Date : $
 * HISTORY   : 
 * COPYRIGHT : Copyright (c) 2003, Fuji Xerox. All rights reserved.
 */
package oracle.apps.xxsc.excel.model;

/**
 * ���i���N���X
 * @author NCD mochiduki
 * @version $Revision :
 */
public class ShipInformation {

	// �Z�b�gID
	private String contractUnitId;
	// �_��A��
	private String contractNumber;
	// �󒍃^�C�v
	private String orderType;
	// �g�DID
	private String orgId;
	// �󒍔ԍ�
	private String orderNumber;
	// ���i�ԍ�
	private String shipNumber;
	// ���k���ד���ID
	private String oppLineId;
	// �_�񖾍ד���ID
	private String indivContrHeaderId;
	// ���׃^�C�v
	private String transactionType;
	// ���׃^�C�v��
	private String transactionTypeName;
	// ����X���Ə��敪
	private String dealershipType;
		
	//------------------ ��������A�N�Z�b�T�E���\�b�h

	/**
	 * @return
	 */
	public String getContractNumber() {
		return contractNumber;
	}

	/**
	 * @return
	 */
	public String getContractUnitId() {
		return contractUnitId;
	}

	/**
	 * @return
	 */
	public String getOrderNumber() {
		return orderNumber;
	}

	/**
	 * @return
	 */
	public String getOrderType() {
		return orderType;
	}

	/**
	 * @return
	 */
	public String getOrgId() {
		return orgId;
	}

	/**
	 * @return
	 */
	public String getShipNumber() {
		return shipNumber;
	}

	/**
	 * @param string
	 */
	public void setContractNumber(String string) {
		contractNumber = string;
	}

	/**
	 * @param string
	 */
	public void setContractUnitId(String string) {
		contractUnitId = string;
	}

	/**
	 * @param string
	 */
	public void setOrderNumber(String string) {
		orderNumber = string;
	}

	/**
	 * @param string
	 */
	public void setOrderType(String string) {
		orderType = string;
	}

	/**
	 * @param string
	 */
	public void setOrgId(String string) {
		orgId = string;
	}

	/**
	 * @param string
	 */
	public void setShipNumber(String string) {
		shipNumber = string;
	}

	/**
	 * @return
	 */
	public String getOppLineId() {
		return oppLineId;
	}

	/**
	 * @param string
	 */
	public void setOppLineId(String string) {
		oppLineId = string;
	}

	/**
	 * @return
	 */
	public String getIndivContrHeaderId() {
		return indivContrHeaderId;
	}

	/**
	 * @param string
	 */
	public void setIndivContrHeaderId(String string) {
		indivContrHeaderId = string;
	}

	/**
	 * @return
	 */
	public String getTransactionType() {
		return transactionType;
	}

	/**
	 * @return
	 */
	public String getTransactionTypeName() {
		return transactionTypeName;
	}

	/**
	 * @param string
	 */
	public void setTransactionType(String string) {
		transactionType = string;
	}

	/**
	 * @param string
	 */
	public void setTransactionTypeName(String string) {
		transactionTypeName = string;
	}

	/**
	 * @return
	 */
	public String getDealershipType() {
		return dealershipType;
	}

	/**
	 * @param string
	 */
	public void setDealershipType(String string) {
		dealershipType = string;
	}

	//------------------ �����܂ŃA�N�Z�b�T�E���\�b�h
	
	/**
	 * �{�I�u�W�F�N�g������������<BR>
	 *
	 * @return		OrderInformation	�������g
	 * @exception	Exception			�������ɃG���[�����������ꍇ
	 */	
	public ShipInformation createModel() throws Exception {
		
		return this;
	}
}
