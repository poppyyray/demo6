/* the Apache Software Foundation license */
/*
 * FILE      : $Header : $
 * VERSION   : $Revision : $
 * DATE      : $Date : $
 * HISTORY   : 
 * COPYRIGHT : Copyright (c) 2003, Fuji Xerox. All rights reserved.
 */
package oracle.apps.xxsc.excel.model;

import java.util.List;
import java.util.Date;


/**
 * IN�@�̃A�t�^�[���<BR>
 * 
 *
 * @author  S.Kobayashi
 * @version $Revision : $
 * 
 */
public class AfterInformationOutItem extends AbstractReportModel {

	// �~�j�}��
	private List minimun;
	// �P�������W
	private List unitRange;


	// �����敪
	private String publicPrivateType;
	// �����܂Ƃߐe�q�敪
	private String chargeComplPrtChdType;
	// �ʌ_�񖾍ד���ID
	private String indivContrLineId;
	// �̔��敪
	private String salesType;
	// �ۊ�敪
	private String ijiKihonType;
	// �����^���_����ԋ敪
	private String rentalContrPeriodType;
	// �ێ�敪
	private String maintenanceType;
	// �����_��w�b�_�[�̓���ID
	private String indivContrHeaderId;
	// �����_�񖾍ׂ̖{��M���הԍ�
	private String lineNumber;
	// �K�p�J�n��
	private Date lineStartDate;
	// �K�p�I����
	private Date lineEndDate;
	// ���i��ދ敪
	private String priceKindType;
	// �_���ދ敪
	private String contractType;
	// MC�v�Z�敪
	private String mcCalculationType;
	// ������ʉ��i�敪
	private String tokushuTokubetsuPrType;
	// ���[�^�[�����K�p�J�n��
	private Date mcStartDate;
	// ���[�^�[�����K�p�I����
	private Date mcEndDate;
	// ���i�̓���ID
	private String inventoryItemId;
	// �����_��̓���ID
	private String compoundContrHeaderId;
	// �v�[�����j�b�g�敪
	private String poolUnitType;
	// ���i�������x��
	private String priceRevisionLevelType;
	// �_�����
	private String compoundContractType;
	// ���F�~�j�}���i�R�s�[�j
	private String tokuninCopyMinimum;
	// ���F�~�j�}���i�\�t�g�E�F�A�j
	private String tokuninSwMinimum;
		
	
	//------------------ ��������A�N�Z�b�T�E���\�b�h
	
	/**
	 * @return
	 */
	public String getChargeComplPrtChdType() {
		return chargeComplPrtChdType;
	}

	/**
	 * @return
	 */
	public String getCompoundContractType() {
		return compoundContractType;
	}

	/**
	 * @return
	 */
	public String getCompoundContrHeaderId() {
		return compoundContrHeaderId;
	}

	/**
	 * @return
	 */
	public String getContractType() {
		return contractType;
	}

	/**
	 * @return
	 */
	public String getIjiKihonType() {
		return ijiKihonType;
	}

	/**
	 * @return
	 */
	public String getIndivContrHeaderId() {
		return indivContrHeaderId;
	}

	/**
	 * @return
	 */
	public String getInventoryItemId() {
		return inventoryItemId;
	}

	/**
	 * @return
	 */
	public Date getLineEndDate() {
		return lineEndDate;
	}

	/**
	 * @return
	 */
	public String getLineNumber() {
		return lineNumber;
	}

	/**
	 * @return
	 */
	public Date getLineStartDate() {
		return lineStartDate;
	}

	/**
	 * @return
	 */
	public String getMaintenanceType() {
		return maintenanceType;
	}

	/**
	 * @return
	 */
	public String getMcCalculationType() {
		return mcCalculationType;
	}

	/**
	 * @return
	 */
	public Date getMcEndDate() {
		return mcEndDate;
	}

	/**
	 * @return
	 */
	public Date getMcStartDate() {
		return mcStartDate;
	}

	/**
	 * @return
	 */
	public List getMinimun() {
		return minimun;
	}

	/**
	 * @return
	 */
	public String getPoolUnitType() {
		return poolUnitType;
	}

	/**
	 * @return
	 */
	public String getPriceKindType() {
		return priceKindType;
	}

	/**
	 * @return
	 */
	public String getPriceRevisionLevelType() {
		return priceRevisionLevelType;
	}

	/**
	 * @return
	 */
	public String getRentalContrPeriodType() {
		return rentalContrPeriodType;
	}

	/**
	 * @return
	 */
	public String getSalesType() {
		return salesType;
	}

	/**
	 * @return
	 */
	public String getTokuninCopyMinimum() {
		return tokuninCopyMinimum;
	}

	/**
	 * @return
	 */
	public String getTokuninSwMinimum() {
		return tokuninSwMinimum;
	}

	/**
	 * @return
	 */
	public String getTokushuTokubetsuPrType() {
		return tokushuTokubetsuPrType;
	}

	/**
	 * @return
	 */
	public List getUnitRange() {
		return unitRange;
	}

	/**
	 * @param string
	 */
	public void setChargeComplPrtChdType(String string) {
		chargeComplPrtChdType = string;
	}

	/**
	 * @param string
	 */
	public void setCompoundContractType(String string) {
		compoundContractType = string;
	}

	/**
	 * @param string
	 */
	public void setCompoundContrHeaderId(String string) {
		compoundContrHeaderId = string;
	}

	/**
	 * @param string
	 */
	public void setContractType(String string) {
		contractType = string;
	}

	/**
	 * @param string
	 */
	public void setIjiKihonType(String string) {
		ijiKihonType = string;
	}

	/**
	 * @param string
	 */
	public void setIndivContrHeaderId(String string) {
		indivContrHeaderId = string;
	}

	/**
	 * @param string
	 */
	public void setInventoryItemId(String string) {
		inventoryItemId = string;
	}

	/**
	 * @param date
	 */
	public void setLineEndDate(Date date) {
		lineEndDate = date;
	}

	/**
	 * @param string
	 */
	public void setLineNumber(String string) {
		lineNumber = string;
	}

	/**
	 * @param date
	 */
	public void setLineStartDate(Date date) {
		lineStartDate = date;
	}

	/**
	 * @param string
	 */
	public void setMaintenanceType(String string) {
		maintenanceType = string;
	}

	/**
	 * @param string
	 */
	public void setMcCalculationType(String string) {
		mcCalculationType = string;
	}

	/**
	 * @param date
	 */
	public void setMcEndDate(Date date) {
		mcEndDate = date;
	}

	/**
	 * @param date
	 */
	public void setMcStartDate(Date date) {
		mcStartDate = date;
	}

	/**
	 * @param list
	 */
	public void setMinimun(List list) {
		minimun = list;
	}

	/**
	 * @param string
	 */
	public void setPoolUnitType(String string) {
		poolUnitType = string;
	}

	/**
	 * @param string
	 */
	public void setPriceKindType(String string) {
		priceKindType = string;
	}

	/**
	 * @param string
	 */
	public void setPriceRevisionLevelType(String string) {
		priceRevisionLevelType = string;
	}

	/**
	 * @param string
	 */
	public void setRentalContrPeriodType(String string) {
		rentalContrPeriodType = string;
	}

	/**
	 * @param string
	 */
	public void setSalesType(String string) {
		salesType = string;
	}

	/**
	 * @param string
	 */
	public void setTokuninCopyMinimum(String string) {
		tokuninCopyMinimum = string;
	}

	/**
	 * @param string
	 */
	public void setTokuninSwMinimum(String string) {
		tokuninSwMinimum = string;
	}

	/**
	 * @param string
	 */
	public void setTokushuTokubetsuPrType(String string) {
		tokushuTokubetsuPrType = string;
	}

	/**
	 * @param list
	 */
	public void setUnitRange(List list) {
		unitRange = list;
	}

	/**
	 * @return
	 */
	public String getPublicPrivateType() {
		return publicPrivateType;
	}

	/**
	 * @param string
	 */
	public void setPublicPrivateType(String string) {
		publicPrivateType = string;
	}

	/**
	 * @return
	 */
	public String getIndivContrLineId() {
		return indivContrLineId;
	}

	/**
	 * @param string
	 */
	public void setIndivContrLineId(String string) {
		indivContrLineId = string;
	}

	//------------------ �����܂ŃA�N�Z�b�T�E���\�b�h

	/**
	 * �{�I�u�W�F�N�g������������<BR>
	 *
	 * @return		AfterInformationOutItem	�������g
	 * @exception	Exception   �������ɃG���[�����������ꍇ
	 */	
	public AfterInformationOutItem createModel() throws Exception {
		
		return this;
	}	


}
