/* the Apache Software Foundation license */
/*
 * FILE      : $Header : $
 * VERSION   : $Revision : $
 * DATE      : $Date : $
 * HISTORY   : 
 * COPYRIGHT : Copyright (c) 2003, Fuji Xerox. All rights reserved.
 */
/*
 * <�C���J�n��> <�Č����i���e�j>
 * 2008/03/13   #107674 ���k��\���̌������i�V��̎�\�����܂ށj
 */
package oracle.apps.xxsc.excel.model;

import java.util.Date;

import oracle.apps.xxsc.excel.business.SalesContractLogic;

/**
 * �����_����<BR>
 * 
 *
 * @author  T.Mochizuki
 * @version $Revision : $
 * 
 */
public class SalesContract {

	// �̔���敪
	private String salesToType;
	// �̔���敪��
	private String salesToTypeName;
	// ���������@�敪
	private String collectionMethodType;
	// ���Ə��R�[�h
	private String salesSiteNumber;
	// ���Ə���
	private String salesSiteName;
	// ���������@
	private String collectionMethodTypeName;
	// ���������t�敔�ۖ�
	private String billToSectionName;
	// ���Z�@�փR�[�h
	private String bankCode;
	// ������ ���Ə��R�[�h
	private String billToCustSiteNumber;
	// ������ ���Ə���
	private String billToCustSiteName;
	// ������ �S���Җ�
	private String billToCustContactName;
	// ������ ���ۖ�
	private String billToCustContactNameExt;
	// ������ �S����TEL
	private String billToCustContactTel;
	// ������ �r���K��
	private String billToFloor;
	// ������ �Z��
	private String billToSiteAddress;
	// �����t���O
	private String installmentFlag;
	// ���� ����
	private String installmentInitialPayment;
	// ���� �c�������x����
	private String installmentRemainPayTimes;
	// ���� �e��x�����z
	private String installmentEachTimePayment;
	// ���� �����x���N����
	private Date installmentInitialPayDate;
	// ���� ����
	private String installmentInterestRate;
	// ���� �e��x����
	private String installmentEachTimeDueDay;
	// ���[�X����
	private String leasePeriodTypeName;
	// ���ԃ��[�X��
	private String leaseMonthAmountFee;
	// ����^�X�|�b�g
	private String leaseTypeName;
	// ���[�X����
	private String leaseChargeRate;
	// ���[�X���D
	private String leaseBid;
	// �_�񏑉���敪
	private String contractCollectType;
	// ������
	private Date orderDate;
	// �擾�\���
	private Date collectScheduleDate;
	// �x���\���
	private Date scheduledPayDate;
	// �ڋq�w�蒍�����ԍ�
	private String custReqOrderSlipNumber;
	// �Ώۋ��z
	private double ObjectAmount = Double.NaN;
	// �����_��A��
	private String salesContractNumber;
	// �������K����
	private Date invoiceArrivalDueDate;
	
// 20080313 #107674 hojo add start
	// �Ώۋ��z�i��\�p�j
	private String payInclusiveAmount;
// 20080313 #107674 hojo add end
	
	//------------------ ��������A�N�Z�b�T�E���\�b�h

	/**
	 * @return
	 */
	public String getSalesToType() {
		return salesToType;
	}

	/**
	 * @return
	 */
	public String getSalesToTypeName() {
		return salesToTypeName;
	}

	/**
	 * @param string
	 */
	public void setSalesToType(String string) {
		salesToType = string;
	}

	/**
	 * @param string
	 */
	public void setSalesToTypeName(String string) {
		salesToTypeName = string;
	}

	/**
	 * @return
	 */
	public String getCollectionMethodType() {
		return collectionMethodType;
	}

	/**
	 * @return
	 */
	public String getCollectionMethodTypeName() {
		return collectionMethodTypeName;
	}

	/**
	 * @param string
	 */
	public void setCollectionMethodType(String string) {
		collectionMethodType = string;
	}

	/**
	 * @param string
	 */
	public void setCollectionMethodTypeName(String string) {
		collectionMethodTypeName = string;
	}

	/**
	 * @return
	 */
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * @return
	 */
	public String getBillToCustContactName() {
		return billToCustContactName;
	}

	/**
	 * @return
	 */
	public String getBillToCustContactNameExt() {
		return billToCustContactNameExt;
	}

	/**
	 * @return
	 */
	public String getBillToCustContactTel() {
		return billToCustContactTel;
	}

	/**
	 * @return
	 */
	public String getBillToCustSiteName() {
		return billToCustSiteName;
	}

	/**
	 * @return
	 */
	public String getBillToCustSiteNumber() {
		return billToCustSiteNumber;
	}

	/**
	 * @return
	 */
	public String getBillToFloor() {
		return billToFloor;
	}

	/**
	 * @return
	 */
	public String getBillToSectionName() {
		return billToSectionName;
	}

	/**
	 * @return
	 */
	public String getBillToSiteAddress() {
		return billToSiteAddress;
	}

	/**
	 * @return
	 */
	public Date getCollectScheduleDate() {
		return collectScheduleDate;
	}

	/**
	 * @return
	 */
	public String getContractCollectType() {
		return contractCollectType;
	}

	/**
	 * @return
	 */
	public String getCustReqOrderSlipNumber() {
		return custReqOrderSlipNumber;
	}

	/**
	 * @return
	 */
	public String getInstallmentEachTimeDueDay() {
		return installmentEachTimeDueDay;
	}

	/**
	 * @return
	 */
	public String getInstallmentEachTimePayment() {
		return installmentEachTimePayment;
	}

	/**
	 * @return
	 */
	public String getInstallmentFlag() {
		return installmentFlag;
	}

	/**
	 * @return
	 */
	public Date getInstallmentInitialPayDate() {
		return installmentInitialPayDate;
	}

	/**
	 * @return
	 */
	public String getInstallmentInitialPayment() {
		return installmentInitialPayment;
	}

	/**
	 * @return
	 */
	public String getInstallmentInterestRate() {
		return installmentInterestRate;
	}

	/**
	 * @return
	 */
	public String getInstallmentRemainPayTimes() {
		return installmentRemainPayTimes;
	}

	/**
	 * @return
	 */
	public String getLeaseChargeRate() {
		return leaseChargeRate;
	}

	/**
	 * @return
	 */
	public String getLeaseBid() {
		return leaseBid;
	}

	/**
	 * @return
	 */
	public String getLeaseMonthAmountFee() {
		return leaseMonthAmountFee;
	}

	/**
	 * @return
	 */
	public String getLeasePeriodTypeName() {
		return leasePeriodTypeName;
	}

	/**
	 * @return
	 */
	public String getLeaseTypeName() {
		return leaseTypeName;
	}

	/**
	 * @return
	 */
	public Date getOrderDate() {
		return orderDate;
	}

	/**
	 * @return
	 */
	public String getSalesSiteName() {
		return salesSiteName;
	}

	/**
	 * @return
	 */
	public String getSalesSiteNumber() {
		return salesSiteNumber;
	}

	/**
	 * @return
	 */
	public Date getScheduledPayDate() {
		return scheduledPayDate;
	}

	/**
	 * @param string
	 */
	public void setBankCode(String string) {
		bankCode = string;
	}

	/**
	 * @param string
	 */
	public void setBillToCustContactName(String string) {
		billToCustContactName = string;
	}

	/**
	 * @param string
	 */
	public void setBillToCustContactNameExt(String string) {
		billToCustContactNameExt = string;
	}

	/**
	 * @param string
	 */
	public void setBillToCustContactTel(String string) {
		billToCustContactTel = string;
	}

	/**
	 * @param string
	 */
	public void setBillToCustSiteName(String string) {
		billToCustSiteName = string;
	}

	/**
	 * @param string
	 */
	public void setBillToCustSiteNumber(String string) {
		billToCustSiteNumber = string;
	}

	/**
	 * @param string
	 */
	public void setBillToFloor(String string) {
		billToFloor = string;
	}

	/**
	 * @param string
	 */
	public void setBillToSectionName(String string) {
		billToSectionName = string;
	}

	/**
	 * @param string
	 */
	public void setBillToSiteAddress(String string) {
		billToSiteAddress = string;
	}

	/**
	 * @param string
	 */
	public void setCollectScheduleDate(Date date) {
		collectScheduleDate = date;
	}

	/**
	 * @param string
	 */
	public void setContractCollectType(String string) {
		contractCollectType = string;
	}

	/**
	 * @param string
	 */
	public void setCustReqOrderSlipNumber(String string) {
		custReqOrderSlipNumber = string;
	}

	/**
	 * @param string
	 */
	public void setInstallmentEachTimeDueDay(String string) {
		installmentEachTimeDueDay = string;
	}

	/**
	 * @param string
	 */
	public void setInstallmentEachTimePayment(String string) {
		installmentEachTimePayment = string;
	}

	/**
	 * @param string
	 */
	public void setInstallmentFlag(String string) {
		installmentFlag = string;
	}

	/**
	 * @param string
	 */
	public void setInstallmentInitialPayDate(Date date) {
		installmentInitialPayDate = date;
	}

	/**
	 * @param string
	 */
	public void setInstallmentInitialPayment(String string) {
		installmentInitialPayment = string;
	}

	/**
	 * @param string
	 */
	public void setInstallmentInterestRate(String string) {
		installmentInterestRate = string;
	}

	/**
	 * @param string
	 */
	public void setInstallmentRemainPayTimes(String string) {
		installmentRemainPayTimes = string;
	}

	/**
	 * @param string
	 */
	public void setLeaseChargeRate(String string) {
		leaseChargeRate = string;
	}

	/**
	 * @param string
	 */
	public void setLeaseBid(String string) {
		leaseBid = string;
	}

	/**
	 * @param string
	 */
	public void setLeaseMonthAmountFee(String string) {
		leaseMonthAmountFee = string;
	}

	/**
	 * @param string
	 */
	public void setLeasePeriodTypeName(String string) {
		leasePeriodTypeName = string;
	}

	/**
	 * @param string
	 */
	public void setLeaseTypeName(String string) {
		leaseTypeName = string;
	}

	/**
	 * @param string
	 */
	public void setOrderDate(Date date) {
		orderDate = date;
	}

	/**
	 * @param string
	 */
	public void setSalesSiteName(String string) {
		salesSiteName = string;
	}

	/**
	 * @param string
	 */
	public void setSalesSiteNumber(String string) {
		salesSiteNumber = string;
	}

	/**
	 * @param string
	 */
	public void setScheduledPayDate(Date date) {
		scheduledPayDate = date;
	}

	/**
	 * @return
	 */
	public double getObjectAmount() {
		return ObjectAmount;
	}

	/**
	 * @param d
	 */
	public void setObjectAmount(double d) {
		ObjectAmount = d;
	}

	/**
	 * @return
	 */
	public String getSalesContractNumber() {
		return salesContractNumber;
	}

	/**
	 * @param string
	 */
	public void setSalesContractNumber(String string) {
		salesContractNumber = string;
	}

	/**
	 * @return
	 */
	public Date getInvoiceArrivalDueDate() {
		return invoiceArrivalDueDate;
	}

	/**
	 * @param string
	 */
	public void setInvoiceArrivalDueDate(Date date) {
		invoiceArrivalDueDate = date;
	}

// 20080313 #107674 hojo add start
	/**
	 * @return
	 */
	public String getPayInclusiveAmount() {
		return payInclusiveAmount;
	}

	/**
	 * @param string
	 */
	public void setPayInclusiveAmount(String payInclusiveAmnt) {
		this.payInclusiveAmount = payInclusiveAmnt;
	}
// 20080313 #107674 hojo add end

	//------------------ �����܂ŃA�N�Z�b�T�E���\�b�h
	
	/**
	 * �{�I�u�W�F�N�g������������<BR>
	 *
	 * @return		SalesContract	�������g
	 * @exception	Exception	   �������ɃG���[�����������ꍇ
	 */	
	public SalesContract createModel() throws Exception {
		
		SalesContractLogic sales = new SalesContractLogic();

		// 1.���Ə���񐬌`
		sales.changeSiteInfoAtDirectSales(this);

		// 2.���������@�敪���`
		sales.makeCollectionMethodTypeName(this);

		return this;
	}
}