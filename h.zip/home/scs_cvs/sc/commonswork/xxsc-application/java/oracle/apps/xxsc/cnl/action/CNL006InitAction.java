/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/cnl/action/CNL006InitAction.java,v 1.1 2004/03/19 15:00:00 t_hatanaka Exp $
 * VERSION   : $Revision: 1.1 $
 * DATE      : $Date: 2004/03/19 15:00:00 $
 * HISTORY   : 
 * COPYRIGHT : (c)Copyright Fuji Xerox Co., Ltd. 2003 All rights reserved.
 *             Copyright(c)Oracle Corporation Japan, 2003. All rights reserved.
 */

package oracle.apps.xxsc.cnl.action;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;

import oracle.apps.xxsc.ActionTemplate;

/**
 * �u�L�����Z���\���o�͉�ʁv�̏����\�������B
 *
 * @author   T.Hatanaka
 * @version  $Revision: 1.1 $
 */
public class CNL006InitAction extends ActionTemplate {
		
	/**
	 * <p>
	 * �����\�������B
	 * </p>
	 *
	 * @param mapping {@link org.apache.struts.action.ActionMapping} �I�u�W�F�N�g
	 * @param form    {@link org.apache.struts.action.DynaActionForm} �I�u�W�F�N�g
	 * @return org.apache.struts.action.ActionForward
	 * @exception java.lang.Exception
	 */
	public ActionForward process(ActionMapping mapping, DynaActionForm form)
		throws Exception {

		getLog().debug("CNL006Init start");

		// ���FormBean����
		DynaActionForm cnl006form = lookupDynaForm("CNL006form");

		// �G���[���b�Z�[�W��������
		cnl006form.set("errInfo", "");

		getLog().debug("CNL006Init end");

		setAttribute("CNL006form", cnl006form, REQUEST);

		return mapping.findForward("success");
	}
}

