/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/auth/DummyGateway.java,v 1.4 2003/09/24 10:16:07 h_okita Exp $
 * VERSION   : $Revision: 1.4 $
 * DATE      : $Date: 2003/09/24 10:16:07 $
 * HISTORY   : 
 * COPYRIGHT : (c)Copyright Fuji Xerox Co., Ltd. 2003 All rights reserved.
 *             Copyright(c)Oracle Corporation Japan, 2003. All rights reserved.
 */


package oracle.apps.xxsc.auth;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.DynaBean;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.config.ModuleConfig;

import oracle.fwk.ext.config.bean.DynaBeanConfig;
import oracle.fwk.ext.struts.ExtStrutsUtils;
import oracle.fwk.ext.struts.config.Gateway;

import oracle.apps.xxsc.XXSC;
import oracle.apps.xxsc.plugin.InitConfigPlugIn;


/**
 * �J���p�F�؃N���X�ł��B
 *
 * @author  Youji, NIHONYANAGI
 * @version  $Revision: 1.4 $ $Date: 2003/09/24 10:16:07 $
 */
public class DummyGateway implements Gateway {


// ---------------------------------------------- Public Methods.
// ------------------------------------------------------------------

	/**
	 * �Z�b�V�����X�R�[�v��EBS��񂪑��݂��Ȃ���΁A<br />
	 * ��������EBS���̃Z�b�g���s���A<code>false</code> ��Ԃ��܂��B
	 *
	 * @see #logIn(HttpServletRequest, HttpServletResponse, ActionServlet)
	 * @param request  {@link javax.servlet.http.HttpServletRequest} �I�u�W�F�N�g
	 * @param response  {@link javax.servlet.http.HttpServletResponse} �I�u�W�F�N�g
	 * @param servlet  {@link org.apache.struts.action.ActionServlet} �I�u�W�F�N�g
	 * @param moduleConfig  {@link org.apache.struts.config.ModuleConfig} �I�u�W�F�N�g
	 * @return boolean  
	 *     �F�،���OK�ł���� <code>false</code>�ANG�ł���� <code>true</code> ��Ԃ��܂��B
	 * @exception java.lang.Exception
	 */
	public final boolean validate(HttpServletRequest request, 
	                              HttpServletResponse response, 
	                              ActionServlet servlet, ModuleConfig moduleConfig) 
	throws Exception {
		if ( request.getSession(false) == null || 
		    request.getSession(false).getAttribute(XXSC.EBS_INFO) == null ) {
			logIn(request, response, servlet);
		}
		
		return false;
	}


// ---------------------------------------------- Protected Methods.
// ------------------------------------------------------------------

	protected void logIn(HttpServletRequest request, 
	                     HttpServletResponse response, 
	                     ActionServlet servlet) {
		DynaBeanConfig beanConfig = 
			ExtStrutsUtils.getGlobalBeanConfig(servlet).findDynaBeanConfig("ebsInformation");
		if ( beanConfig == null ) {
			throw new IllegalStateException("beanConfig[ebsInformation] is null ...");
		}
		
		DynaBean ebsInfo = beanConfig.getDynaBean();
		
		InitConfigPlugIn initConfig = 
			(InitConfigPlugIn)servlet.getServletContext().getAttribute(XXSC.INIT_PLUGIN);
		
		ebsInfo.set("userId", initConfig.findInitParameter("userId"));
		ebsInfo.set("respId", initConfig.findInitParameter("respId"));
		ebsInfo.set("respAppId", initConfig.findInitParameter("respAppId"));
		ebsInfo.set("securityGroupId", initConfig.findInitParameter("securityGroupId"));
		ebsInfo.set("ebsSessionId", initConfig.findInitParameter("ebsSessionId"));
		ebsInfo.set("transactionId", initConfig.findInitParameter("transactionId"));
		ebsInfo.set("languageCode", initConfig.findInitParameter("languageCode"));
		ebsInfo.set("nlsLanguage", initConfig.findInitParameter("nlsLanguage"));
		ebsInfo.set("dateFormatmask", initConfig.findInitParameter("dateFormatmask"));
		ebsInfo.set("nlsDateLanguage", initConfig.findInitParameter("nlsDateLanguage"));
		ebsInfo.set("nlsNumericCharacters", initConfig.findInitParameter("nlsNumericCharacters"));
		ebsInfo.set("nlsSort", initConfig.findInitParameter("nlsSort"));
		ebsInfo.set("nlsTerritory", initConfig.findInitParameter("nlsTerritory"));
		
		ebsInfo.set("httpSessionId", request.getSession(true).getId());
		ebsInfo.set("remoteAddr", request.getRemoteAddr());
		ebsInfo.set("userAgent", request.getHeader("user-agent"));
		
		request.getSession(true).setAttribute(XXSC.EBS_INFO, ebsInfo);
	}


}

