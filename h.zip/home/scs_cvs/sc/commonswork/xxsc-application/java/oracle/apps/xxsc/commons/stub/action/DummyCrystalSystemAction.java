/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/commons/stub/action/DummyCrystalSystemAction.java,v 1.3 2003/09/08 12:58:23 y_shigeta Exp $
 * VERSION   : $Revision: 1.3 $
 * DATE      : $Date: 2003/09/08 12:58:23 $
 * HISTORY   : 
 * COPYRIGHT : (c)Copyright Fuji Xerox Co., Ltd. 2003 All rights reserved.
 *             Copyright(c)Oracle Corporation Japan, 2003. All rights reserved.
 */

package oracle.apps.xxsc.commons.stub.action;

import java.util.List;
import java.util.ArrayList;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;

import oracle.apps.xxsc.ActionTemplate;


/**
 * <p><h3>�^��Crystal���i��������</h3></p>
 *
 * <p>
 * ���ύ̎Z����Ăяo�����CrystalSystem��Stub�B
 * �_�~�[��ʂ֏��̏o�́B
 * </p>
 *
 * @author Yuichi Masumiya
 * @version $Revision: 1.3 $
 */
public class DummyCrystalSystemAction extends ActionTemplate {

	/**
	 * <p>
	 * POST�f�[�^�o�͏���
	 * </p>
	 *
	 * @param mapping  {@link org.apache.struts.action.ActionMapping} �I�u�W�F�N�g
	 * @param form  {@link org.apache.struts.action.DynaActionForm} �I�u�W�F�N�g
	 * @return org.apache.struts.action.ActionForward
	 * @exception java.lang.Exception
	 */
	public ActionForward process(ActionMapping mapping, DynaActionForm form) 
		throws Exception {

		String[] listItem = new String[18];
		List crystalList = new ArrayList();

		getLog().debug(form);

		if (getInitParameter("Crystal/counter") != null
			&& !"".equals(getInitParameter("Crystal/counter"))) {
			for (int i = 0; i < Integer.parseInt(getInitParameter("Crystal/counter")); i++) {

				DynaActionForm daf = lookupDynaForm("SAL003_crystalItemLineList");

				listItem[0]  = "Crystal/oppLineNo_"            + (i + 1); // ���i���הԍ�
				listItem[1]  = "Crystal/itemDescript_"         + (i + 1); // ���i����
				listItem[2]  = "Crystal/makerModelNo_"         + (i + 1); // ���[�J�[�^��
				listItem[3]  = "Crystal/makerName_"            + (i + 1); // ���[�J�[��
				listItem[4]  = "Crystal/venderName_"           + (i + 1); // �x���_�[��
				listItem[5]  = "Crystal/noOfItems_"            + (i + 1); // ����
				listItem[6]  = "Crystal/salesListPrice_"       + (i + 1); // �W�����i
				listItem[7]  = "Crystal/invoicePrice_"         + (i + 1); // �d�؉��i
				listItem[8]  = "Crystal/venderContactName_"    + (i + 1); // �x���_�[����
				listItem[9]  = "Crystal/venderDepartmentName_" + (i + 1); // �x���_�[�S����
				listItem[10] = "Crystal/venderTel_"            + (i + 1); // �x���_�[TEL
				listItem[11] = "Crystal/venderEstimateNo_"     + (i + 1); // �d���挩�ϔԍ�
				listItem[12] = "Crystal/venderCode_"           + (i + 1); // �x���_�[�R�[�h
				listItem[13] = "Crystal/makerCode_"            + (i + 1); // ���[�J�[�R�[�h
				listItem[14] = "Crystal/venderItemCode_"       + (i + 1); // �d���揤�i�R�[�h
				listItem[15] = "Crystal/dataSelectType_"       + (i + 1); // �f�[�^�I���敪
				listItem[16] = "Crystal/openPriceType_"        + (i + 1); // �I�[�v�����i�敪�t���O
				listItem[17] = "Crystal/lineStatus_"           + (i + 1); // ���׍X�V�w���敪

				getLog().debug("Counter -> [ " + i + " ]");

				daf.set("oppLineNo",            getInitParameter(listItem[0]));
				daf.set("itemDescript",         getInitParameter(listItem[1]));
				daf.set("makerModelNo",         getInitParameter(listItem[2]));
				daf.set("makerName",            getInitParameter(listItem[3]));
				daf.set("venderName",           getInitParameter(listItem[4]));
				daf.set("noOfItems",            getInitParameter(listItem[5]));
				daf.set("salesListPrice",       getInitParameter(listItem[6]));
				daf.set("invoicePrice",         getInitParameter(listItem[7]));
				daf.set("venderContactName",    getInitParameter(listItem[8]));
				daf.set("venderDapartmentName", getInitParameter(listItem[9]));
				daf.set("venderTel",            getInitParameter(listItem[10]));
				daf.set("venderEstimateNo",     getInitParameter(listItem[11]));
				daf.set("venderCode",           getInitParameter(listItem[12]));
				daf.set("makerCode",            getInitParameter(listItem[13]));
				daf.set("venderItemCode",       getInitParameter(listItem[14]));
				daf.set("dataSelectType",       getInitParameter(listItem[15]));
				daf.set("openPriceType",        getInitParameter(listItem[16]));
				daf.set("lineStatus",           getInitParameter(listItem[17]));

				for (int j = 0; j < 18; j++) {
					getLog().debug(listItem[j] + " -> [ " + getInitParameter(listItem[j]) + " ]");
				}

				getLog().debug(daf);

				crystalList.add(daf);

				getLog().debug(crystalList);

			}

			form.set("crystalItemLineList", crystalList);

			setAttribute("SAL003_crystal", form, REQUEST);
		}


		return mapping.findForward("success");
	}

}

