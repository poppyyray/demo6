/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/commons/filter/ParameterDebugFilter.java,v 1.5 2003/09/24 09:57:18 s_kusumi Exp $
 * VERSION   : $Revision: 1.5 $
 * DATE      : $Date: 2003/09/24 09:57:18 $
 * HISTORY   : 
 * COPYRIGHT : (c)Copyright Fuji Xerox Co., Ltd. 2003 All rights reserved.
 *             Copyright(c)Oracle Corporation Japan, 2003. All rights reserved.
 */

package oracle.apps.xxsc.commons.filter;

import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import oracle.fwk.ext.util.StringUtil;


/**
 * web.xml �Ɏw�肵�����O���܂ރp�����[�^���ƃp�����[�^�l���f�o�b�O�o�͂��܂��B
 *
 * @author  Youji, NIHONYANAGI
 * @version  $Revision: 1.5 $ $Date: 2003/09/24 09:57:18 $
 */
public class ParameterDebugFilter implements Filter {


// ---------------------------------------------- Public Methods.
// ------------------------------------------------------------------

	/**
	 * ���������s���܂��B
	 *
	 * @param filterConfig  {@link javax.servlet.FilterConfig} �I�u�W�F�N�g
	 * @exception javax.servlet.ServletException
	 */
	public final void init(FilterConfig filterConfig) throws ServletException {
		this.ignore = 
			StringUtil.toBoolean(filterConfig.getInitParameter("ignore"));
		if ( ignore ) {
			this.keyWords = null;
		} else {
			this.keyWords = 
				StringUtil.toArray(filterConfig.getInitParameter("keyWords"), ",");
			if ( 0 < this.keyWords.length && "*".equals(this.keyWords[0]) ) {
				this.all = true;
			}
		}
	}


	/**
	 * �j���������s���܂��B
	 */
	public final void destroy() {
		this.keyWords = null;
		this.all = false;
		this.ignore = false;
	}


	/**
	 * web.xml �Ɏw�肳��Ă���p�����[�^�ɑ΂��āA���O�ƒl���f�o�b�O�o�͂��܂��B
	 *
	 * @param request  {@link javax.servlet.ServletRequest} �I�u�W�F�N�g
	 * @param response  {@link javax.servlet.ServletResponse} �I�u�W�F�N�g
	 * @param chain  {@link javax.servlet.FilterChain} �I�u�W�F�N�g
	 * @exception java.io.IOException
	 * @exception javax.servlet.ServletException
	 */
	public final void doFilter(ServletRequest request, ServletResponse response, 
	                           FilterChain chain) 
	throws IOException, ServletException {
		if ( this.ignore || !LOG.isDebugEnabled() ) {
			chain.doFilter(request, response);
		}
		
		String paramName = null;
		String paramValue = null;
		Enumeration params = request.getParameterNames();
		while ( params.hasMoreElements() ) {
			paramName = (String)params.nextElement();
			if ( !isTargetParameter(paramName) ) {
				continue;
			}
			paramValue = 
				StringUtils.defaultString(request.getParameter(paramName), "NULL");
			LOG.debug(
				"[PARAMETER] - name:[" + paramName + "], value:[" + paramValue + "] ...");
		}
		
		chain.doFilter(request, response);
	}


// ---------------------------------------------- Protected Methods.
// ------------------------------------------------------------------

	protected boolean isTargetParameter(String parameterName) {
		if ( this.all ) {
			return true;
		}
		for (int i = 0; i < this.keyWords.length; i++) {
			if ( parameterName.indexOf(keyWords[i]) != -1 ) {
				return true;
			}
		}
		return false;
	}


// ---------------------------------------------- Instance Fields.
// ------------------------------------------------------------------

	protected String[] keyWords;

	protected boolean all = false;

	protected boolean ignore = false;


// ---------------------------------------------- Logging Fields.
// ------------------------------------------------------------------

	private static final Logger LOG = Logger.getLogger("biz");


}
