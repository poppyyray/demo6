/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/commons/plugin/LookupPlugIn.java,v 1.8 2003/09/24 10:30:10 s_kusumi Exp $
 * VERSION   : $Revision: 1.8 $
 * DATE      : $Date: 2003/09/24 10:30:10 $
 * HISTORY   : 
 * COPYRIGHT : (c)Copyright Fuji Xerox Co., Ltd. 2003 All rights reserved.
 *             Copyright(c)Oracle Corporation Japan, 2003. All rights reserved.
 */

package oracle.apps.xxsc.commons.plugin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletException;

import org.apache.commons.digester.Digester;
import org.apache.commons.digester.RuleSet;
import org.apache.commons.digester.RuleSetBase;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.action.DynaActionForm;
import org.apache.struts.action.PlugIn;
import org.apache.struts.config.ModuleConfig;

import oracle.fwk.ext.Globals;
import oracle.fwk.ext.config.dbif.Sql;
import oracle.fwk.ext.config.dbif.SqlConfig;
import oracle.fwk.ext.config.ds.DataSourceConfig;
import oracle.fwk.ext.struts.ActionFormUtil;
import oracle.fwk.ext.struts.DigesterPlugIn;
import oracle.fwk.ext.struts.ExtStrutsUtils;


/**
 * ���b�N�A�b�v�e�[�u���ɓo�^����Ă���}�X�^�f�[�^�̎擾���s���A<br />
 * �A�v���P�[�V�����ɓo�^���܂��B<br /><br />
 *
 * <strong>lookup-plugin.xml</strong> ��ǂݍ��݁A�o�^���郋�b�N�A�b�v�^�C�v�����肵�܂��B
 *
 * @author  Youji, NIHONYANAGI
 * @version  $Revision: 1.8 $ $Date: 2003/09/24 10:30:10 $
 */
public class LookupPlugIn extends DigesterPlugIn implements PlugIn {


// ---------------------------------------------- Constructors.
// ------------------------------------------------------------------

	/**
	 * �f�t�H���g�R���X�g���N�^
	 */
	public LookupPlugIn() {
		super();
		this.lookupTypes = new ArrayList(40);
	}


// ---------------------------------------------- Public Methods.
// ------------------------------------------------------------------


	public void addLookupConfig(LookupConfig lookupConfig) {
		// Verify ...
		verifyNoConfigured();
		verifyArg(notNull(lookupConfig), "lookupConfig is null");
		verifyArg(notEmpty(lookupConfig.getKey()), "lookupConfig.key is empty");
		verifyArg(notEmpty(lookupConfig.getLookupType()), "lookupConfig.lookupType is empty");
		
		this.lookupTypes.add(lookupConfig);
	}


// ---------------- Getter.
// --------------------------

	public String getLookupQuery() { return this.lookupQuery; }


	public String getDatasourceKey() { return this.datasourceKey; }


// ---------------- Setter.
// --------------------------

	public void setLookupQuery(String str) { this.lookupQuery = str; }


	public void setDatasourceKey(String str) { this.datasourceKey = str; }


// ---------------------------------------------- Protected Methods.
// ------------------------------------------------------------------

	/**
	 * �����������s���܂��B
	 *
	 * @exception java.lang.Exception
	 */
	protected void initResources() throws Exception {
		LookupConfig lookupConfig = null;
		LookupBean bean = null;
		List lookupList = null;
		DynaActionForm lookupRecord = null;
		
		Sql sql = findSql();
		Connection connection = findConnection();
		PreparedStatement preStmt = null;
		ResultSet rs = null;
		
		try {
			preStmt = connection.prepareStatement(sql.getPreBindedStmt());
			
			Iterator types = this.lookupTypes.iterator();
			while ( types.hasNext() ) {
				lookupConfig = (LookupConfig)types.next();
				bean = new LookupBean();
				bean.setLookupType(lookupConfig.getLookupType());
				lookupList = new ArrayList();
				
				preStmt.setString(1, lookupConfig.getLookupType());
				rs = preStmt.executeQuery();
				
				while ( rs.next() ) {
					lookupRecord = findLookupRecord();
					
					lookupRecord.set("value", rs.getString("lookup_code"));
					lookupRecord.set("label", rs.getString("meaning"));
					lookupRecord.set("lookupCode", rs.getString("lookup_code"));
					lookupRecord.set("meaning", rs.getString("meaning"));
					lookupRecord.set("description", rs.getString("description"));
					lookupRecord.set("attribute1", rs.getString("attribute1"));
					lookupRecord.set("attribute2", rs.getString("attribute2"));
					lookupRecord.set("attribute3", rs.getString("attribute3"));
					lookupRecord.set("attribute4", rs.getString("attribute4"));
					lookupRecord.set("attribute5", rs.getString("attribute5"));
					lookupRecord.set("attribute6", rs.getString("attribute6"));
					lookupRecord.set("attribute7", rs.getString("attribute7"));
					lookupRecord.set("attribute8", rs.getString("attribute8"));
					lookupRecord.set("attribute9", rs.getString("attribute9"));
					lookupRecord.set("attribute10", rs.getString("attribute10"));
					lookupRecord.set("attribute11", rs.getString("attribute11"));
					lookupRecord.set("attribute12", rs.getString("attribute12"));
					lookupRecord.set("attribute13", rs.getString("attribute13"));
					lookupRecord.set("attribute14", rs.getString("attribute14"));
					lookupRecord.set("attribute15", rs.getString("attribute15"));
					lookupList.add(lookupRecord);
				}
				bean.setLookupList(lookupList);
				this.servlet.getServletContext().setAttribute(lookupConfig.getKey(), bean);
			}
			
			types = null;
		} catch (SQLException sqlEx) {
			throw sqlEx;
		} finally {
			if ( rs != null ) {
				rs.close();
				rs = null;
			}
			if ( preStmt != null ) {
				preStmt.close();
				preStmt = null;
			}
			if ( connection != null && !connection.isClosed() ) {
				connection.close();
				connection = null;
			}
		}
	}


	/**
	 * �j���������s���܂��B
	 */
	protected void destroyResources() {
		if ( this.lookupTypes != null ) {
			this.lookupTypes.clear();
			this.lookupTypes = null;
		}
		this.lookupQuery = null;
		this.datasourceKey = Globals.DEFAULT_DS_KEY;
	}


	/**
	 * {@link LookupRuleSet} �C���X�^���X��Ԃ��܂��B
	 *
	 * @return org.apache.commons.digester.RuleSet
	 */
	protected RuleSet defaultRuleSet() {
		return new LookupRuleSet();
	}


// ---------------------------------------------- Private Methods.
// ------------------------------------------------------------------

	private Sql findSql() {
		// Verify ...
		verifyState(notEmpty(this.lookupQuery), "lookupQuery is empty");
		
		// Return SqlConfig ...
		SqlConfig sqlConfig = 
			ExtStrutsUtils.getGlobalDBIfConfig(this.servlet).findSqlConfig(this.lookupQuery);
		
		// Verify ...
		verifyState(notNull(sqlConfig), "sqlConfig:[" + this.lookupQuery + "] is null");
		
		return sqlConfig.createSql();
	}


	private Connection findConnection() throws SQLException {
		// Verify ...
		verifyState(notEmpty(this.datasourceKey), "datasourceKey is empty");
		
		// Return DataSourceConfig ...
		DataSourceConfig dsConfig = 
			ExtStrutsUtils.getGlobalDataSourceConfig(this.servlet).findDataSourceConfig(this.datasourceKey);
		
		// Verify ...
		verifyState(notNull(dsConfig), "dsConfig:[" + this.datasourceKey + "] is null");
		
		return dsConfig.getConnection();
	}


	private DynaActionForm findLookupRecord() {
		return ActionFormUtil.lookupDynaForm(
			"LookupRecord", this.servlet, this.moduleConfig);
	}


// ---------------------------------------------- Properties.
// ------------------------------------------------------------------

	private List lookupTypes;

	private String lookupQuery;

	private String datasourceKey = Globals.DEFAULT_DS_KEY;


}


// ---------------------------------------------- RuleSet Class.
// ------------------------------------------------------------------

/**
 * <strong>lookup-plugin.xml</strong> ��ǂݍ��ވׂ̃��[���Z�b�g�N���X�ł��B
 *
 * @author  Youji, NIHONYANAGI
 * @version  $Revision: 1.8 $ $Date: 2003/09/24 10:30:10 $
 */
class LookupRuleSet extends RuleSetBase implements RuleSet {


	/**
	 *
	 * @param digester  XML��͎��ɐ�������� {@link org.apache.commons.digester.Digester} �C���X�^���X
	 */
	public void addRuleInstances(Digester digester) {
		digester.addObjectCreate(
			"lookup-plugin/lookup-type", "oracle.apps.xxsc.commons.plugin.LookupConfig", "className");
		digester.addSetProperties("lookup-plugin/lookup-type");
		digester.addSetNext(
			"lookup-plugin/lookup-type", "addLookupConfig", "oracle.apps.xxsc.commons.plugin.LookupConfig");
	}


}


