/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/cnl/action/CNL008InitAction.java,v 1.0 2008/05/07 15:00:00 K.Takayama Exp $
 * VERSION   : $Revision: 1.0 $
 * DATE      : $Date: 2008/05/07 15:00:00 $
 * HISTORY   : 
 * COPYRIGHT : (c)Copyright Fuji Xerox Co., Ltd. 2003 All rights reserved.
 *             Copyright(c)Oracle Corporation Japan, 2003. All rights reserved.
 */

package oracle.apps.xxsc.cnl.action;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;

import oracle.apps.xxsc.ActionTemplate;

/**
 * �u��������C���˗��^�L�����Z���\���o�͈˗��v�̓��e�\�������B
 *
 * @author   Xiaolong.Wang
 * @version  $Revision: 1.0 $
 */
public class CNL008ShowAction extends ActionTemplate {
		
	/**
	 * <p>
	 * ���e�\��
	 * </p>
	 *
	 * @param mapping {@link org.apache.struts.action.ActionMapping} �I�u�W�F�N�g
	 * @param form    {@link org.apache.struts.action.DynaActionForm} �I�u�W�F�N�g
	 * @return org.apache.struts.action.ActionForward
	 * @exception java.lang.Exception
	 */
	public ActionForward process(ActionMapping mapping, DynaActionForm form)
		throws Exception {

		String hdOppCode = (String)form.get("hdOppCode");
    	String meaning ="";
    	String salesrep_number = "";
    	String name = "";
    	String opp_creation_date = "";
		if(StringUtils.isNotEmpty(hdOppCode)){
	        setSql("testsql");
	        setParam(1, hdOppCode); // ���k�R�[�h
	        executeQuery();
	        // ���k���擾        
	        if (hasNextRow()) {
	        	meaning = getRowStr("meaning");
	        	salesrep_number = getRowStr("salesrep_number");
	        	name = getRowStr("name");
	        	opp_creation_date = getRowStr("opp_creation_date");
	        }
		}
		form.set("salesrepNumber", salesrep_number);
		form.set("salesrepName", name);
		form.set("opportunitiesStatus", meaning);
		form.set("oppCreationDate", opp_creation_date);
        setAttribute("CNL008form", form, REQUEST);
		return mapping.findForward("success");
	}
}

