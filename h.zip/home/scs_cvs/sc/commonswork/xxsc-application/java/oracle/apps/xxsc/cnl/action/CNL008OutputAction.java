/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/cnl/action/CNL008OutputAction.java,v 1.0 2008/05/07 15:00:00 K.Takayama Exp $
 * VERSION   : $Revision: 1.0 $
 * DATE      : $Date: 2008/05/07 15:00:00 $
 * HISTORY   : 
 * COPYRIGHT : (c)Copyright Fuji Xerox Co., Ltd. 2003 All rights reserved.
 *             Copyright(c)Oracle Corporation Japan, 2003. All rights reserved.
 */

package oracle.apps.xxsc.cnl.action;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;

import oracle.apps.xxsc.ActionTemplate;
import org.apache.struts.util.ModuleException;

/**
 * �u��������C���˗��^�L�����Z���\���o�͈˗��v�̏o�͏����B
 *
 * @author   K.Takayama
 * @version  $Revision: 1.0 $
 */
public class CNL008OutputAction extends ActionTemplate {

	/**
	 * <p>
	 * �o�͏����B
	 * </p>
	 *
	 * @param mapping {@link org.apache.struts.action.ActionMapping} �I�u�W�F�N�g
	 * @param form    {@link org.apache.struts.action.DynaActionForm} �I�u�W�F�N�g
	 * @return org.apache.struts.action.ActionForward
	 * @exception java.lang.Exception
	 */
	public ActionForward process(ActionMapping mapping, DynaActionForm form)
		throws Exception {
		
		String outputType = (String)form.get("outputType");

		// �o�̓`�F�b�N
		if ("cancel".equals(outputType)) {

			setAttribute("CNL008form", form, REQUEST);

			return mapping.findForward("success1");

		/******2009/02/02 SE����˗��ɑ΂���u�^�����v�̏o�͑Ή�  hui.ouyang Mod Start******/
//		} else {
//
//			setAttribute("CNL008form", form, REQUEST);
//
//			return mapping.findForward("success2");
//
//		}
		} else if("secancel".equals(outputType)){

			setAttribute("CNL008form", form, REQUEST);

			return mapping.findForward("success3");

		} else{
			
			setAttribute("CNL008form", form, REQUEST);
			
			return mapping.findForward("success2");
			
		}
		/******2009/02/02 SE����˗��ɑ΂���u�^�����v�̏o�͑Ή�  hui.ouyang Mod end******/
	}

}