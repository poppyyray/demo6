/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/commons/stub/action/ExcelStubAction.java,v 1.1 2003/09/04 06:46:58 msuda Exp $
 * VERSION   : $Revision: 1.1 $
 * DATE      : $Date: 2003/09/04 06:46:58 $
 * HISTORY   : 
 * COPYRIGHT : Copyright (c) 2002-2003, Oracle Corporation Japan. All rights reserved.
 */
package oracle.apps.xxsc.commons.stub.action;


import java.util.Date;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;
import org.apache.commons.beanutils.DynaBean;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import oracle.apps.xxsc.ActionTemplate;
import oracle.fwk.ext.Globals;
import oracle.fwk.ext.struts.ExtStrutsUtils;

/**
 * <p>
 * <h3>
 * EXCEL���[�o�̓X�^�u�A�N�V�����N���X
 * </h3>
 * </p>
 *
 * @author Masashi Suda
 * @version $Revision: 1.1 $
 */
public class ExcelStubAction extends ActionTemplate {

	private static final short  COL       = 1;
	private static final int    ROW       = 2;
	private static final String FILE_NAME = "���[�o�̓e�X�g";
	private static final String EXTENSION = "xls";

	/**
	 * <p>
	 * </p>
	 * 
	 * @param mapping  {@link org.apache.struts.action.ActionMapping} �I�u�W�F�N�g
	 * @param form  {@link org.apache.struts.action.DynaActionForm} �I�u�W�F�N�g
	 * @return org.apache.struts.action.ActionForward
	 * @exception java.lang.Exception
	 */
	public ActionForward process( ActionMapping mapping, DynaActionForm form )
		throws Exception {

		String           dir   = getInitParameter( "directory" );
		String           tmp   = getInitParameter( "template" );
		FileInputStream  fis   = new FileInputStream( dir + "/" + tmp );
		POIFSFileSystem  fs    = new POIFSFileSystem( fis );
		HSSFWorkbook     wb    = new HSSFWorkbook( fs );
		HSSFSheet        sheet = wb.getSheetAt( 0 );
		HSSFCell         cell  = null;
		SimpleDateFormat sdf   = new SimpleDateFormat( "yyyy/MM/dd HH:mm:ss" );

		cell = getCell( sheet, ROW, COL );
		cell.setCellValue( "�ق��ق� " + sdf.format( new Date() ) );

		String fileName = FILE_NAME + "." + EXTENSION;
		fileName = new String( fileName.getBytes( "Shift_JIS" ), "ISO8859_1" );

		HttpServletResponse res = getResponse();
		res.setContentType( getInitParameter( "mimeType" ) );
		res.setHeader( "Content-Disposition",
		               "attachment;filename=\"" + fileName + "\"" );
		ServletOutputStream sos = res.getOutputStream();
		wb.write( sos );
		sos.close();
		fis.close();

		return null;
	}

	/**
	 * HSSFRow �擾
	 *
	 * @param  HSSFSheet sheet
	 * @param  int       row
	 * @return HSSFSheet
	 */
	private HSSFRow getRow( HSSFSheet sheet, int row ) {

		return sheet.getRow( row ) != null
		     ? sheet.getRow( row )
		     : sheet.createRow( row );
	}

	/**
	 * HSSFCell �擾
	 *
	 * @param  HSSFRow row
	 * @param  short   col
	 * @return HSSFCell
	 */
	private HSSFCell getCell( HSSFRow row, short col ) {

		HSSFCell cell = row.getCell( col ) != null
		              ? row.getCell( col )
		              : row.createCell( col );
		cell.setEncoding( HSSFCell.ENCODING_UTF_16 );
		return cell;
	}

	/**
	 * HSSFCell �擾
	 *
	 * @param  HSSFSheet sheet
	 * @param  int       row
	 * @param  short     col
	 * @return HSSFCell
	 */
	private HSSFCell getCell( HSSFSheet sheet, int row, short col ) {

		return getCell( getRow( sheet, row ), col );
	}

	/**
	 * FORMULA �ݒ�
	 *
	 * @param  HSSFSheet sheet
	 * @param  int       row
	 * @param  short     col
	 * @return HSSFCell
	 */
	private void setFormula( HSSFCell cell ) {

		cell.setCellFormula( cell.getCellFormula() );
		cell.setCellStyle( cell.getCellStyle() );
		cell.setCellType( cell.getCellType() );
	}
}
