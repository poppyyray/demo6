/* the Apache Software Foundation license */
/*
 * FILE      : $Header : $
 * VERSION   : $Revision : $
 * DATE      : $Date : $
 * HISTORY   :
 * COPYRIGHT : Copyright (c) 2003, Fuji Xerox. All rights reserved.
 */
package oracle.apps.xxsc.excel.action;

import java.util.List;
import java.util.Vector;

import oracle.apps.xxsc.ActionTemplate;
import oracle.apps.xxsc.excel.DSXlsInterface;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;

/**
 * �ݒu���擾����
 *
 * @author  NCD
 * @version $Revision: $
 */
public final class InstallationInfoAction extends ActionTemplate {

	/**
	 * �ݒu���擾�A�N�V��������
	 *
	 * @param     ActionMapping  mapping
	 * @param     DynaActionForm install
	 * @return    ActionForward
	 * @exception Exception
	 */
	public final ActionForward process(ActionMapping mapping, DynaActionForm install) throws Exception {
		getLog().debug("===<< InstallationInfoAction >>===<< START >> ");

		//�c�a�����E���ʕҏW�������ďo���B
		referenceDesign(install);

		getLog().debug("===<< InstallationInfoAction >>===<< END >> ");
		return null; // ��ʑJ�ڂȂ�
	}

	/**
	 * �c�a�����E���ʕҏW
	 *     �c�a�̌����������s��
	 *
	 * @param     DynaActionForm install
	 * @return
	 * @exception Exception
	 */
	private void referenceDesign(DynaActionForm install) throws Exception {
		getLog().debug("===<< InstallationInfoAction/referenceDesign >>===<< START >> ");

		//�ݒu���擾����
		List params = new Vector();
		setSql("EXCEL_DS060");
		params.add(install.get("setID")); // �Z�b�g�h�c�j�d�x
		setParams(params);
		executeQuery();
		if (hasNextRow()) {
			//�ݒu���擾����
			DynaActionForm wk_install = getRow(DSXlsInterface.L_INSTALL);
			install.set("installationSiteId",(String)wk_install.get("installationSiteId"));
			install.set("locationName",(String)wk_install.get("locationName"));
			install.set("province",(String)wk_install.get("province"));
			install.set("city",(String)wk_install.get("city"));
			install.set("address1",(String)wk_install.get("address1"));
			install.set("address2",(String)wk_install.get("address2"));
			install.set("address3",(String)wk_install.get("address3"));
			install.set("sectionName",(String)wk_install.get("sectionName"));
			install.set("contactName",(String)wk_install.get("contactName"));
			install.set("tel",(String)wk_install.get("tel"));
			install.set("elevatorFlag",(String)wk_install.get("elevatorFlag"));
			install.set("stairConfigurationName",(String)wk_install.get("stairConfigurationName"));
			install.set("numberOfStairsteps",(String)wk_install.get("numberOfStairsteps"));
			install.set("returnValue", DSXlsInterface.RETUEN_OK);
		} else {
			//�ݒu���擾���s
			install.set("returnValue", DSXlsInterface.RETUEN_NG);
		}

		getLog().debug("===<< InstallationInfoAction/referenceDesign >>===<< END >> ");
	}
}