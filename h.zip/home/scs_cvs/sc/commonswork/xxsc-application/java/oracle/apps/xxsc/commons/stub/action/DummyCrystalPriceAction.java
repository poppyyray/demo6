/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/commons/stub/action/DummyCrystalPriceAction.java,v 1.2 2003/09/24 10:15:42 h_okita Exp $
 * VERSION   : $Revision: 1.2 $
 * DATE      : $Date: 2003/09/24 10:15:42 $
 * HISTORY   : 
 * COPYRIGHT : (c)Copyright Fuji Xerox Co., Ltd. 2003 All rights reserved.
 *             Copyright(c)Oracle Corporation Japan, 2003. All rights reserved.
 */
package oracle.apps.xxsc.commons.stub.action;

import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.commons.beanutils.DynaBean;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.DynaActionForm;
import org.apache.struts.action.ActionMapping;

import oracle.apps.xxsc.ActionTemplate;

/**
 * <p><h3>�^��Crystal�ŐV���i�擾</h3></p>
 *
 * <p>
 * �������i�ݒ�iCrystal�j����Ăяo�����CrystalSystem��Stub�B
 * �_�~�[��ʂ֏��̏o�́B
 * </p>
 *
 * @author Tatsuya Seki
 * @version $Revision: 1.2 $
 */
public class DummyCrystalPriceAction extends ActionTemplate {

    // EBS�������i�ݒ���̃}�b�s���O
    private Map cry001dataMap = new HashMap();

	/**
	 * <p>
	 * POST�f�[�^�o�͏���
	 * </p>
	 *
	 * @param mapping  {@link org.apache.struts.action.ActionMapping} �I�u�W�F�N�g
	 * @param form  {@link org.apache.struts.action.DynaActionForm} �I�u�W�F�N�g
	 * @return org.apache.struts.action.ActionForward
	 * @exception java.lang.Exception
	 */
	public ActionForward process(ActionMapping mapping, DynaActionForm form) 
		throws Exception {

		getLog().debug(" �� class : DummyCrystalPriceAction ");

        // --------------------- get POST data ---------------------------------

        getLog().debug(" �� POST data : Price data list ");
        // Post�f�[�^���擾
        Enumeration paramNames = request.getParameterNames();
        while ( paramNames.hasMoreElements() ) {
            String parameterKey = (String) paramNames.nextElement();
            String parameterValue
                = (String) request.getParameter(parameterKey);

            cry001dataMap.put(parameterKey, parameterValue);              
        }
        getLog().debug(" �� POST data : Price data list ");

        // set new submit data from Mapping Object 
        getLog().debug(" �� POST data : new Price data list ");

        // get Map Object size.
        int idx = 1;

        // �f�o�b�N�p
        request.setAttribute("callback_url", 
                             cry001dataMap.get("callback_url"));

        // set opportunities_number.
        request.setAttribute("opportunities_number", 
                             cry001dataMap.get("opportunities_number"));

        ArrayList submitList = new ArrayList();

        HashMap map = new HashMap();
        boolean loopFlag = true;

        while ( loopFlag ) {

            // �L�[�̍쐬
            String keyVenderCode
                = new String("vender_code_");
            String keyMakerModelNumber
                = new String("maker_model_number_");
            String keyMakerCode
                = new String("maker_code_");

            // �C���f�b�N�X�̕t��
            keyVenderCode = keyVenderCode + String.valueOf(idx);
            keyMakerModelNumber = keyMakerModelNumber + String.valueOf(idx);
            keyMakerCode = keyMakerCode + String.valueOf(idx);

            // loop continue judgement.
            if ( !cry001dataMap.containsKey(keyVenderCode) &&
                 !cry001dataMap.containsKey(keyMakerModelNumber) &&
                 !cry001dataMap.containsKey(keyMakerCode) ) {

                getLog().debug(" �� POST data : new Price data list ");
                break;

            }

            // return constant values.
            map.put(keyVenderCode, cry001dataMap.get(keyVenderCode));
            map.put(keyMakerModelNumber, cry001dataMap.get(keyMakerModelNumber));
            map.put(keyMakerCode, cry001dataMap.get(keyMakerCode));

            submitList.add(map);
            idx++;
        }

        // set list data.
        request.setAttribute("submitData", submitList);

        getLog().debug(" �� POST data : new Price data list ");
		getLog().debug(" �� class : CrystalNewPriceAction ");

		return mapping.findForward("success");
    }
}