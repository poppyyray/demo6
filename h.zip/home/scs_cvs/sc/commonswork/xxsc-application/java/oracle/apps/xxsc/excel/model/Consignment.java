/* the Apache Software Foundation license */
/*
 * FILE      : $Header : $
 * VERSION   : $Revision : $
 * DATE      : $Date : $
 * HISTORY   : 
 * COPYRIGHT : Copyright (c) 2003, Fuji Xerox. All rights reserved.
 */
package oracle.apps.xxsc.excel.model;

/**
 * �ϑ����<BR>
 * 
 *
 * @author  T.Mochizuki
 * @version $Revision : $
 * 
 */
public class Consignment {

	// �Z�b�g����ID
	private String oppContractUnitId;
	// �ϑ��^�C�v
	private String consignmentCode;
	// �ϑ��敪
	private String consignmentTypeCode;

	// �J�X�ǁi�\���p�j
	private String custmerManageType;
	// �ϑ��i�\���p�j
	private String businessCosignmentType;

	// �����^���J�X�Ǌ�{��
	private String rentalBaseCharge;
	// �K�p��_�c��
	private String salesRate;
	// �K�p��_�T�[�r�X
	private String serviceRate;
	// �K�p��_���Օi
	private String commodityRate;
	// �K�p��_���̑�
	private String othersRate;
	// �ʊz_�Ɩ��ϑ�
	private String operationConsAmount;
	// �ʊz_�T�[�r�X�ϑ�
	private String serviceConsAmount;
	// �x�����ЃR�[�h
	private String billToCustomerNumber;
	// �x�����Ж�
	private String billToCustomerName;
	// �̔�����ЃR�[�h
	private String saleToCustomerNumber;
	// �̔�����Ж�
	private String salesToCustomerName;

	//------------------ ��������A�N�Z�b�T�E���\�b�h
	
	/**
	 * @return
	 */
	public String getConsignmentCode() {
		return consignmentCode;
	}

	/**
	 * @return
	 */
	public String getConsignmentTypeCode() {
		return consignmentTypeCode;
	}

	/**
	 * @return
	 */
	public String getOppContractUnitId() {
		return oppContractUnitId;
	}

	/**
	 * @param string
	 */
	public void setConsignmentCode(String string) {
		consignmentCode = string;
	}

	/**
	 * @param string
	 */
	public void setConsignmentTypeCode(String string) {
		consignmentTypeCode = string;
	}

	/**
	 * @param string
	 */
	public void setOppContractUnitId(String string) {
		oppContractUnitId = string;
	}
	
	/**
	 * @return
	 */
	public String getBusinessCosignmentType() {
		return businessCosignmentType;
	}

	/**
	 * @return
	 */
	public String getCustmerManageType() {
		return custmerManageType;
	}

	/**
	 * @param string
	 */
	public void setBusinessCosignmentType(String string) {
		businessCosignmentType = string;
	}

	/**
	 * @param string
	 */
	public void setCustmerManageType(String string) {
		custmerManageType = string;
	}

	/**
	 * @return
	 */
	public String getCommodityRate() {
		return commodityRate;
	}

	/**
	 * @return
	 */
	public String getRentalBaseCharge() {
		return rentalBaseCharge;
	}

	/**
	 * @return
	 */
	public String getSalesRate() {
		return salesRate;
	}

	/**
	 * @return
	 */
	public String getServiceRate() {
		return serviceRate;
	}

	/**
	 * @param string
	 */
	public void setCommodityRate(String string) {
		commodityRate = string;
	}

	/**
	 * @param string
	 */
	public void setRentalBaseCharge(String string) {
		rentalBaseCharge = string;
	}

	/**
	 * @param string
	 */
	public void setSalesRate(String string) {
		salesRate = string;
	}

	/**
	 * @param string
	 */
	public void setServiceRate(String string) {
		serviceRate = string;
	}

	/**
	 * @return
	 */
	public String getBillToCustomerName() {
		return billToCustomerName;
	}

	/**
	 * @return
	 */
	public String getBillToCustomerNumber() {
		return billToCustomerNumber;
	}

	/**
	 * @return
	 */
	public String getSalesToCustomerName() {
		return salesToCustomerName;
	}

	/**
	 * @return
	 */
	public String getSaleToCustomerNumber() {
		return saleToCustomerNumber;
	}

	/**
	 * @param string
	 */
	public void setBillToCustomerName(String string) {
		billToCustomerName = string;
	}

	/**
	 * @param string
	 */
	public void setBillToCustomerNumber(String string) {
		billToCustomerNumber = string;
	}

	/**
	 * @param string
	 */
	public void setSalesToCustomerName(String string) {
		salesToCustomerName = string;
	}

	/**
	 * @param string
	 */
	public void setSaleToCustomerNumber(String string) {
		saleToCustomerNumber = string;
	}

	/**
	 * @return
	 */
	public String getOperationConsAmount() {
		return operationConsAmount;
	}

	/**
	 * @return
	 */
	public String getOthersRate() {
		return othersRate;
	}

	/**
	 * @return
	 */
	public String getServiceConsAmount() {
		return serviceConsAmount;
	}

	/**
	 * @param string
	 */
	public void setOperationConsAmount(String string) {
		operationConsAmount = string;
	}

	/**
	 * @param string
	 */
	public void setOthersRate(String string) {
		othersRate = string;
	}

	/**
	 * @param string
	 */
	public void setServiceConsAmount(String string) {
		serviceConsAmount = string;
	}

	//------------------ �����܂ŃA�N�Z�b�T�E���\�b�h
	
	/**
	 * �{�I�u�W�F�N�g������������<BR>
	 *
	 * @return		Consignment	�������g
	 * @exception	Exception   �������ɃG���[�����������ꍇ
	 */	
	public Consignment createModel() throws Exception {
		
		return this;
	}
}
