/* the Apache Software Foundation license */
/*
 * FILE      : $Header: /u04/cvs/dev/cvsroot/sc/commonswork/xxsc-application/java/oracle/apps/xxsc/ext/action/SAL009InitAction.java,v 1.0 2007/06/20 G.Kikuchi Exp $
 * VERSION   : $Revision: 1.0 $
 * DATE      : $Date: 2007/06/20 $
 * HISTORY   :
 * COPYRIGHT : (c)Copyright Fuji Xerox Co., Ltd. 2006 All rights reserved.
 *             Copyright(c)Oracle Corporation Japan, 2006. All rights reserved.
 */

package oracle.apps.xxsc.sal.action;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;

import javax.servlet.http.HttpServletRequest;

import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import org.apache.struts.util.ModuleException;

import oracle.apps.xxsc.ActionTemplate;
import oracle.fwk.ext.config.dbif.Sql;

/**
 * <p><h3>���׏��ꗗ�����\������</h3></p>
 *
 * <p>
 * ���׏��ꗗ��\������B
 * </p>
 *
 * @author NCD G.Kikuchi
 * @version $Revision: 1.0 $ $Date: 2007/06/20 $
 */
public class SAL009InitAction extends ActionTemplate {

    /**
     * <p>
     * �����\�����̏��������܂�
     * </p>
     *
     * @param mapping  {@link org.apache.struts.action.ActionMapping} �I�u�W�F�N�g
     * @param form  {@link org.apache.struts.action.DynaActionForm} �I�u�W�F�N�g
     * @return org.apache.struts.action.ActionForward
     * @exception java.lang.Exception
     */
    public ActionForward process(ActionMapping mapping, DynaActionForm form)
        throws Exception {

        DynaActionForm sal009Form = lookupDynaForm("SAL009form");

        // �N�G���X�g�����O�������n���ꂽ�l���擾����
        HttpServletRequest request = getRequest();
        String oppCode         = (String)request.getParameter("oppCode");
        String stSetId         = (String)request.getParameter("stSetId");
        String setId           = (String)request.getParameter("setId");
        String contractSeq     = (String)request.getParameter("contractSeq");
        String contractHdrIid  = (String)request.getParameter("contractHdrIid");
        String wkCmplFlag      = (String)request.getParameter("wkCmplFlag");      
        
        getLog().debug("oppCode:" + oppCode);
        getLog().debug("stSetId:" + stSetId);
        getLog().debug("setId:" + setId);
        getLog().debug("contractSeq:" + contractSeq);
        getLog().debug("contractHdrIid:" + contractHdrIid);
        getLog().debug("wkCmplFlag:" + wkCmplFlag);
        
        // ���׏��ꗗ���擾���ݒ肷��
        setOppListDataToForm(sal009Form, oppCode, stSetId, setId, contractSeq,
                contractHdrIid, wkCmplFlag);
        setAttribute("SAL009form", sal009Form, REQUEST);
        return mapping.findForward("success");

    }

    /**
     * <p>
     * ���׏��ꗗ��ݒ肷��
     * </p>
     *
     * @param sal009Form     �u���׏��ꗗ�v�̃f�[�^�ێ��I�u�W�F�N�g
     * @param oppCode         ���k�R�[�h
     * @param stSetId         �_��P�ʘA��
     * @param setId           �Z�b�g����ID
     * @param contractSeq     �_��A��
     * @param contractHdrIid  �ʌ_�����ID
     * @param wkCmplFlag      ��ƍς݃t���O
     * 
     */
    private void setOppListDataToForm
        (DynaActionForm sal009Form, String oppCode, String stSetId, String setId, String contractSeq
        , String contractHdrIid, String wkCmplFlag) throws SQLException, ModuleException {

        Sql sql = lookupSql("1908");
        
        // �_��̗L���ɂ�������ύX
        if ("".equals(contractHdrIid)) {
        	
        	sql.preBind(1, "AND NOT EXISTS (SELECT * "
        								 + "FROM apps.xxmb_indiv_contr_headers_s_v ich "
        								 + "WHERE odrl.attribute8 = ich.indiv_contr_header_id) ");
        	setSql(sql);
        	setParam(1, setId);
        } else {
        	
        	sql.preBind(1, "AND odrl.attribute8 = ? ");
        	setSql(sql);
        	setParam(1, setId);
        	setParam(2, contractHdrIid);
        }

        // ���׏��ꗗ�擾
        executeQuery();
        sal009Form.set("oppLineRefTbl", getRowSet("SAL009_oppLineRefTbl"));
        
        // �_��P�ʂ̏���ݒ�
        sal009Form.set("oppCode", oppCode);
        sal009Form.set("stSetId", stSetId);
        sal009Form.set("contractSeq", contractSeq);
        if ("Y".equals(wkCmplFlag)) {
        	
        	sal009Form.set("finishedFlag", "on");
        }
    }
}